import { createReadStream, existsSync, statSync } from 'node:fs'
import { createServer } from 'node:http'
import { createBrotliCompress, createGzip } from 'node:zlib'
import { extname, join, normalize, resolve, sep } from 'node:path'
import startServer from './dist/server/server.js'

const port = Number(process.env.PORT ?? 3000)
const host = process.env.HOST ?? '0.0.0.0'
const distDir = resolve('dist/client')

const mimeTypes = {
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.png': 'image/png',
  '.webp': 'image/webp',
  '.mp4': 'video/mp4',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.txt': 'text/plain; charset=utf-8',
  '.xml': 'application/xml; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.webmanifest': 'application/manifest+json; charset=utf-8',
  '.ico': 'image/x-icon',
  '.avif': 'image/avif',
  '.map': 'application/json; charset=utf-8',
}

// Text files worth compressing. Images, video and fonts are already compressed.
const compressible = new Set(['.css', '.js', '.svg', '.txt', '.xml', '.json', '.webmanifest', '.map'])

function cacheControl(pathname) {
  // Build output is fingerprinted, so it can be cached for a year.
  if (pathname.startsWith('/assets/')) {
    return 'public, max-age=31536000, immutable'
  }

  return 'public, max-age=3600'
}

function getStaticPath(pathname) {
  const decoded = decodeURIComponent(pathname)
  const normalized = normalize(decoded).replace(/^([/\\])+/, '')
  const filePath = resolve(join(distDir, normalized))

  if (filePath !== distDir && !filePath.startsWith(`${distDir}${sep}`)) {
    return null
  }

  if (!existsSync(filePath)) {
    return null
  }

  const stats = statSync(filePath)
  return stats.isFile() ? { filePath, stats } : null
}

function serveStatic(req, res, pathname) {
  if (req.method !== 'GET' && req.method !== 'HEAD') {
    return false
  }

  const staticFile = getStaticPath(pathname)
  if (!staticFile) {
    return false
  }

  const ext = extname(staticFile.filePath).toLowerCase()
  const type = mimeTypes[ext] ?? 'application/octet-stream'
  const acceptEncoding = String(req.headers['accept-encoding'] ?? '')
  const encoding = !compressible.has(ext)
    ? null
    : acceptEncoding.includes('br')
      ? 'br'
      : acceptEncoding.includes('gzip')
        ? 'gzip'
        : null

  const headers = {
    'content-type': type,
    'cache-control': cacheControl(pathname),
    vary: 'Accept-Encoding',
  }

  if (encoding) {
    headers['content-encoding'] = encoding
  } else {
    headers['content-length'] = staticFile.stats.size
  }

  res.writeHead(200, headers)

  if (req.method === 'HEAD') {
    res.end()
    return true
  }

  const source = createReadStream(staticFile.filePath)

  if (encoding === 'br') {
    source.pipe(createBrotliCompress()).pipe(res)
  } else if (encoding === 'gzip') {
    source.pipe(createGzip()).pipe(res)
  } else {
    source.pipe(res)
  }

  return true
}

async function handleRequest(req, res) {
  const origin = `http://${req.headers.host ?? `localhost:${port}`}`
  const url = new URL(req.url ?? '/', origin)

  if (serveStatic(req, res, url.pathname)) {
    return
  }

  const request = new Request(url, {
    method: req.method,
    headers: req.headers,
    body: req.method === 'GET' || req.method === 'HEAD' ? undefined : req,
    duplex: 'half',
  })

  const response = await startServer.fetch(request)
  res.writeHead(response.status, Object.fromEntries(response.headers))

  if (req.method === 'HEAD' || !response.body) {
    res.end()
    return
  }

  const reader = response.body.getReader()
  while (true) {
    const { done, value } = await reader.read()
    if (done) break
    res.write(value)
  }
  res.end()
}

createServer((req, res) => {
  handleRequest(req, res).catch((error) => {
    console.error(error)
    res.writeHead(500, { 'content-type': 'text/plain; charset=utf-8' })
    res.end('Internal Server Error')
  })
}).listen(port, host, () => {
  console.log(`Listening on http://localhost:${port}`)
})
