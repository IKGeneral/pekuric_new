import { writeFile } from 'node:fs/promises'
import { execFileSync } from 'node:child_process'
import { projects } from '../src/data/projects.ts'
import { articles } from '../src/data/articles.ts'
import {
  SITE_URL,
  absoluteUrl,
  canonicalUrl,
  siteFacts,
  staticPages,
} from '../src/lib/site-facts.ts'

/**
 * Writes public/sitemap.xml and public/llms.txt at build time.
 * Every URL comes from the same canonical rules the page head uses, so the
 * sitemap and the canonical tags always match.
 */

// Source files that decide when each static page last changed. Used only for
// lastmod. When git history is not available the date is left out, because a
// wrong lastmod is worse than none.
const pageSources = {
  '/': ['src/routes/_layout.index.tsx', 'src/pages/Home.tsx', 'src/data/content.ts'],
  '/our-company': ['src/routes/_layout.our-company.tsx', 'src/pages/Company.tsx'],
  '/our-services': ['src/routes/_layout.our-services.tsx', 'src/pages/Services.tsx'],
  '/our-projects': ['src/routes/_layout.our-projects.index.tsx', 'src/data/projects.ts'],
  '/contact-us': ['src/routes/_layout.contact-us.tsx', 'src/pages/Contact.tsx'],
  '/privacy-policy': ['src/routes/_layout.privacy-policy.tsx', 'src/pages/PrivacyPolicy.tsx'],
  '/terms-and-conditions': [
    'src/routes/_layout.terms-and-conditions.tsx',
    'src/pages/TermsAndConditions.tsx',
  ],
  '/news-insights': ['src/routes/_layout.news-insights.tsx', 'src/data/articles.ts'],
  '/category/construction': [
    'src/routes/_layout.category.construction.tsx',
    'src/data/articles.ts',
  ],
}

const gitDate = (files) => {
  try {
    const out = execFileSync('git', ['log', '-1', '--format=%cs', '--', ...files], {
      cwd: new URL('..', import.meta.url),
      stdio: ['ignore', 'pipe', 'ignore'],
    })
      .toString()
      .trim()
    return /^\d{4}-\d{2}-\d{2}$/.test(out) ? out : null
  } catch {
    return null
  }
}

const escapeXml = (value) =>
  value
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&apos;')

const entries = []

for (const page of staticPages) {
  entries.push({
    loc: canonicalUrl(page.path, page.trailingSlash),
    lastmod: gitDate(pageSources[page.path] ?? []),
    images: [],
  })
}

for (const article of articles) {
  entries.push({
    loc: canonicalUrl(`/${article.slug}`, true),
    lastmod: article.publishDate,
    images: [{ loc: absoluteUrl(article.image), title: article.title }],
  })
}

const projectsDate = gitDate(['src/data/projects.ts'])

for (const project of projects) {
  entries.push({
    loc: canonicalUrl(`/our-projects/${project.slug}`),
    lastmod: projectsDate,
    images: [project.image, ...(project.gallery ?? [])].map((src, index) => ({
      loc: absoluteUrl(src),
      title: index === 0 ? project.title : `${project.title}, photo ${index}`,
    })),
  })
}

const urlBlock = (entry) => {
  const lines = [`    <loc>${escapeXml(entry.loc)}</loc>`]

  if (entry.lastmod) {
    lines.push(`    <lastmod>${entry.lastmod}</lastmod>`)
  }

  for (const image of entry.images) {
    lines.push(
      '    <image:image>',
      `      <image:loc>${escapeXml(image.loc)}</image:loc>`,
      `      <image:title>${escapeXml(image.title)}</image:title>`,
      '    </image:image>',
    )
  }

  return `  <url>\n${lines.join('\n')}\n  </url>`
}

const sitemap = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">
${entries.map(urlBlock).join('\n')}
</urlset>
`

await writeFile(new URL('../public/sitemap.xml', import.meta.url), sitemap)

const { contact, abujaOffice } = siteFacts

const llms = `# ${siteFacts.name}

> ${siteFacts.summary}

Service area: Benin City and Edo State (home base), the South South and South West regions, and nationwide in Nigeria.

## Services
- [Our Services](${canonicalUrl('/our-services')}): ${siteFacts.serviceNames.map((name) => name.toLowerCase()).join(', ')}

## Projects
${projects
  .map(
    (project) =>
      `- [${project.title}](${canonicalUrl(`/our-projects/${project.slug}`)}): ${project.category}, ${project.location}. ${project.summary}`,
  )
  .join('\n')}
- [All projects](${canonicalUrl('/our-projects')})

## Company
- [Our Company](${canonicalUrl('/our-company')}): background, values, safety and equipment fleet
- [Contact](${canonicalUrl('/contact-us')}): offices, phone and email

## Articles
${articles
  .map(
    (article) =>
      `- [${article.title}](${canonicalUrl(`/${article.slug}`, true)}): ${article.excerpt}`,
  )
  .join('\n')}

## Contact
- Head office: ${contact.address}
- Abuja office: ${abujaOffice.address}
- Email: ${contact.email}
- Phone: ${contact.phones.join(', ')}
- LinkedIn: ${siteFacts.sameAs[0]}
- Instagram: ${siteFacts.sameAs[1]}
- Website: ${SITE_URL}
`

await writeFile(new URL('../public/llms.txt', import.meta.url), llms)
