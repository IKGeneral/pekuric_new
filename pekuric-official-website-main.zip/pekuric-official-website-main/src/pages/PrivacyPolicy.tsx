import PageHeader from '@/components/PageHeader'
import { privacyPolicy } from '@/data/content'

export default function PrivacyPolicy() {
  return (
    <>
      <PageHeader
        label={privacyPolicy.label}
        title={privacyPolicy.title}
        intro={privacyPolicy.intro}
      />

      <section className="container-t1 pb-24">
        <p className="max-w-2xl text-body-sm font-normal text-carbon-warm/50">
          {privacyPolicy.updated}
        </p>

        <div className="mt-12 flex flex-col gap-12 border-t border-carbon-warm/20 pt-12">
          {privacyPolicy.sections.map((section) => (
            <div key={section.heading} className="max-w-2xl">
              <h2 className="text-heading font-light leading-tight tracking-[0.32px] text-carbon-warm">
                {section.heading}
              </h2>
              <p className="mt-4 text-body font-normal text-carbon-warm/75">
                {section.body}
              </p>
            </div>
          ))}

          <div className="max-w-2xl">
            <h2 className="text-heading font-light leading-tight tracking-[0.32px] text-carbon-warm">
              {privacyPolicy.contact.heading}
            </h2>
            <p className="mt-4 text-body font-normal text-carbon-warm/75">
              {privacyPolicy.contact.body}
            </p>
            <address className="mt-4 flex flex-col gap-1 text-body font-normal not-italic text-carbon-warm/75">
              <span>PEKURIC Limited</span>
              <span>{privacyPolicy.contact.address}</span>
              <a
                href={`mailto:${privacyPolicy.contact.email}`}
                className="transition-colors hover:text-carbon-warm"
              >
                {privacyPolicy.contact.email}
              </a>
              {privacyPolicy.contact.phones.map((phone) => (
                <a
                  key={phone}
                  href={`tel:${phone.replace(/[^+\d]/g, '')}`}
                  className="transition-colors hover:text-carbon-warm"
                >
                  {phone}
                </a>
              ))}
            </address>
          </div>
        </div>
      </section>
    </>
  )
}
