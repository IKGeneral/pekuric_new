import Hero from '@/components/Hero'
import About from '@/components/About'
import Stats from '@/components/Stats'
import Clients from '@/components/Clients'
import ImagePair from '@/components/ImagePair'
import Services from '@/components/Services'
import Projects from '@/components/Projects'
import Capabilities from '@/components/Capabilities'
import Testimonial from '@/components/Testimonial'
import Careers from '@/components/Careers'

export default function Home() {
  return (
    <>
      <Hero />
      <About />
      <Stats />
      <Clients />
      <ImagePair />
      <Services />
      <Projects />
      <Capabilities />
      <Testimonial />
      <Careers />
    </>
  )
}
