import { Link } from '@tanstack/react-router'
import PageHeader from '@/components/PageHeader'
import ContactCTA from '@/components/ContactCTA'
import { projectsPage } from '@/data/content'

export default function Projects() {
  return (
    <>
      <PageHeader
        label={projectsPage.label}
        title={projectsPage.title}
        intro={projectsPage.intro}
      />

      {/* Project gallery */}
      <section className="container-t1 pb-24">
        <div className="grid gap-x-8 gap-y-14 sm:grid-cols-2">
          {projectsPage.cards.map((card) => (
            <Link
              key={card.slug}
              to="/our-projects/$slug"
              params={{ slug: card.slug }}
              className="group block"
            >
              <div className="aspect-[4/3] overflow-hidden rounded-card">
                <img
                  src={card.image}
                  alt={`${card.title}, ${card.location}`}
                  className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                  loading="lazy"
                />
              </div>
              <div className="mt-6 flex items-start justify-between gap-4">
                <div>
                  <h2 className="text-subheading font-normal text-carbon-warm">
                    {card.title}
                  </h2>
                  <p className="mt-1 text-body-sm font-normal text-carbon-warm/60">
                    {card.location}
                  </p>
                </div>
                <span className="shrink-0 rounded-pill border border-carbon-warm/30 px-4 py-1.5 text-label font-normal uppercase tracking-[0.12em] text-carbon-warm/70">
                  {card.category}
                </span>
              </div>
              {card.description && (
                <p className="mt-3 max-w-md text-body-sm font-normal text-carbon-warm/70">
                  {card.description}
                </p>
              )}
            </Link>
          ))}
        </div>
      </section>

      <ContactCTA />
    </>
  )
}
