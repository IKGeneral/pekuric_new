import PageHeader from '@/components/PageHeader'
import SectionLabel from '@/components/SectionLabel'
import Stats from '@/components/Stats'
import ContactCTA from '@/components/ContactCTA'
import { companyPage } from '@/data/content'

export default function Company() {
  const { principles, values, safety } = companyPage

  return (
    <>
      <PageHeader
        label={companyPage.label}
        title={companyPage.title}
        intro={companyPage.intro}
      />

      {/* Full-bleed company image */}
      <section className="container-t1">
        <div className="aspect-[16/9] overflow-hidden rounded-card">
          <img
            src={companyPage.image}
            alt={companyPage.imageAlt}
            className="h-full w-full object-cover"
          />
        </div>
      </section>

      {/* Vision, Mission & Culture */}
      <section className="container-t1 py-24">
        <SectionLabel>{principles.label}</SectionLabel>
        <div className="mt-12 grid gap-x-12 gap-y-12 border-t border-carbon-warm/20 pt-12 md:grid-cols-3">
          {principles.items.map((item) => (
            <div key={item.title}>
              <h3 className="text-heading font-light leading-tight tracking-[0.32px] text-carbon-warm">
                {item.title}
              </h3>
              <p className="mt-4 text-body font-normal text-carbon-warm/75">
                {item.body}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* Core values */}
      <section className="container-t1 pb-24">
        <SectionLabel>{values.label}</SectionLabel>
        <p className="mt-8 max-w-2xl text-[clamp(24px,3vw,32px)] font-light leading-tight tracking-[0.32px] text-carbon-warm">
          {values.intro}
        </p>

        <div className="mt-16 grid gap-x-12 gap-y-12 border-t border-carbon-warm/20 pt-12 sm:grid-cols-2">
          {values.items.map((value) => (
            <div key={value.title} className="flex gap-6">
              <span className="text-body-sm font-normal text-mercury">
                {value.no}
              </span>
              <div>
                <h3 className="text-subheading font-normal text-carbon-warm">
                  {value.title}
                </h3>
                <p className="mt-2 max-w-sm text-body font-normal text-carbon-warm/70">
                  {value.body}
                </p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* By the numbers */}
      <Stats />

      {/* Safety */}
      <section className="container-t1 py-12">
        <div className="grid items-center gap-10 rounded-[48px] bg-carbon-warm px-8 py-16 text-paper-white md:grid-cols-12 md:px-16 md:py-20">
          <div className="md:col-span-4">
            <div className="text-[clamp(64px,10vw,120px)] font-light leading-none tracking-[0.52px]">
              {safety.metric}
            </div>
            <p className="mt-4 max-w-[16rem] text-body-sm font-normal text-paper-white/60">
              {safety.metricCaption}
            </p>
          </div>
          <div className="md:col-span-8">
            <SectionLabel onDark>{safety.label}</SectionLabel>
            <h2 className="mt-6 text-[clamp(26px,3.5vw,40px)] font-light leading-tight tracking-[0.3px]">
              {safety.headline}
            </h2>
            <p className="mt-4 max-w-xl text-body font-normal text-paper-white/70">
              {safety.body}
            </p>
          </div>
        </div>
      </section>

      <ContactCTA />
    </>
  )
}
