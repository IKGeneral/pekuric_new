import PageHeader from '@/components/PageHeader'
import ContactCTA from '@/components/ContactCTA'
import { articles } from '@/data/articles'

export default function CategoryConstruction() {
  const filtered = articles.filter((article) => article.category === 'Construction')

  return (
    <>
      <PageHeader
        label="Category"
        title="Construction"
        intro="Articles filed under Construction."
      />

      <section className="container-t1 pb-24">
        <ul className="grid gap-x-8 gap-y-14 sm:grid-cols-2">
          {filtered.map((article) => (
            <li key={article.slug}>
              <a href={`/${article.slug}/`} className="group block">
                <div className="aspect-[4/3] overflow-hidden rounded-card">
                  <img
                    src={article.image}
                    alt={article.title}
                    className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                    loading="lazy"
                  />
                </div>
                <h2 className="mt-6 text-subheading font-normal text-carbon-warm">
                  {article.title}
                </h2>
                <p className="mt-3 max-w-md text-body-sm font-normal text-carbon-warm/70">
                  {article.excerpt}
                </p>
              </a>
            </li>
          ))}
        </ul>
      </section>

      <ContactCTA />
    </>
  )
}
