import { Link } from '@tanstack/react-router'
import PageHeader from '@/components/PageHeader'
import SectionLabel from '@/components/SectionLabel'
import Capabilities from '@/components/Capabilities'
import { Button } from '@/components/ui/button'
import { servicesPage } from '@/data/content'

export default function Services() {
  return (
    <>
      <PageHeader
        label={servicesPage.label}
        title={servicesPage.title}
        intro={servicesPage.intro}
      />

      {/* Services list — numbered specification-sheet rows */}
      <section className="container-t1 pb-24">
        <div className="border-t border-carbon-warm/60">
          {servicesPage.items.map((item) => (
            <div
              key={item.title}
              id={item.id}
              className="grid gap-4 border-b border-carbon-warm/60 py-10 md:grid-cols-12 md:gap-8"
            >
              <div className="flex items-baseline gap-4 md:col-span-5">
                <span className="text-body-sm font-normal text-mercury">
                  {item.no}
                </span>
                <h2 className="text-heading font-light leading-tight tracking-[0.32px] text-carbon-warm">
                  {item.title}
                </h2>
              </div>
              <p className="text-body font-normal text-carbon-warm/75 md:col-span-7 md:pt-2">
                {item.body}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* Plant & capabilities */}
      <Capabilities />

      {/* Talk to an expert */}
      <section className="container-t1 py-12">
        <div className="flex flex-col items-start gap-8 rounded-[48px] bg-carbon-warm px-8 py-16 text-paper-white md:flex-row md:items-center md:justify-between md:px-16 md:py-20">
          <div className="max-w-xl">
            <SectionLabel onDark>{servicesPage.cta.label}</SectionLabel>
            <p className="mt-6 text-[clamp(24px,3vw,36px)] font-light leading-tight tracking-[0.3px]">
              {servicesPage.cta.body}
            </p>
          </div>
          <Button asChild variant="onDark" className="shrink-0">
            <Link to={servicesPage.cta.to}>{servicesPage.cta.button}</Link>
          </Button>
        </div>
      </section>
    </>
  )
}
