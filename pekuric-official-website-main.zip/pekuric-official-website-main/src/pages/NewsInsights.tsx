import PageHeader from '@/components/PageHeader'
import ContactCTA from '@/components/ContactCTA'
import { articles } from '@/data/articles'

export default function NewsInsights() {
  return (
    <>
      <PageHeader
        label="News & Insights"
        title="Ideas, guidance, and updates from the Pekuric team."
        intro="Practical advice on construction, renovation, and building sustainably."
      >
        <a
          href="/category/construction/"
          className="mt-8 inline-flex min-h-11 items-center rounded-pill border border-carbon-warm/30 px-5 text-label font-normal uppercase tracking-[0.12em] text-carbon-warm/70 transition-colors hover:border-carbon-warm hover:text-carbon-warm"
        >
          Construction
        </a>
      </PageHeader>

      <section className="container-t1 pb-24">
        <ul className="grid gap-x-8 gap-y-14 sm:grid-cols-2">
          {articles.map((article) => (
            <li key={article.slug}>
              <a href={`/${article.slug}/`} className="group block">
                <div className="aspect-[4/3] overflow-hidden rounded-card">
                  <img
                    src={article.image}
                    alt={article.title}
                    className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                    loading="lazy"
                  />
                </div>
                <div className="mt-6 flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
                  <h2 className="text-subheading font-normal text-carbon-warm">
                    {article.title}
                  </h2>
                  <span className="w-fit shrink-0 rounded-pill border border-carbon-warm/30 px-4 py-1.5 text-label font-normal uppercase tracking-[0.12em] text-carbon-warm/70">
                    {article.category}
                  </span>
                </div>
                <p className="mt-3 max-w-md text-body-sm font-normal text-carbon-warm/70">
                  {article.excerpt}
                </p>
              </a>
            </li>
          ))}
        </ul>
      </section>

      <ContactCTA />
    </>
  )
}
