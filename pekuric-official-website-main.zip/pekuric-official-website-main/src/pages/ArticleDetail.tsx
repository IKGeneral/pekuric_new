import PageHeader from '@/components/PageHeader'
import ContactCTA from '@/components/ContactCTA'
import { getArticleBySlug } from '@/data/articles'

export default function ArticleDetail({ slug }: { slug: string }) {
  const article = getArticleBySlug(slug)

  if (!article) {
    return null
  }

  return (
    <>
      <PageHeader
        label={article.category}
        title={article.title}
        intro={article.excerpt}
      >
        <p className="mt-6 text-body-sm font-normal text-carbon-warm/50">
          By {article.author} on{' '}
          <time dateTime={article.publishDate}>
            {new Intl.DateTimeFormat('en', {
              month: 'long',
              day: 'numeric',
              year: 'numeric',
            }).format(new Date(`${article.publishDate}T00:00:00Z`))}
          </time>
        </p>
      </PageHeader>

      <article className="container-t1 pb-24">
        <div className="aspect-[16/9] overflow-hidden rounded-card">
          <img
            src={article.image}
            alt={article.title}
            className="h-full w-full object-cover"
          />
        </div>

        <div className="mt-14 flex flex-col gap-12">
          <p className="max-w-2xl text-body font-normal text-carbon-warm/80">
            {article.intro}
          </p>

          {article.body.map((block) => (
            <section key={block.heading} className="max-w-2xl">
              <h2 className="text-heading font-light leading-tight tracking-[0.32px] text-carbon-warm">
                {block.heading}
              </h2>
              {block.paragraph && (
                <p className="mt-4 text-body font-normal text-carbon-warm/75">
                  {block.paragraph}
                </p>
              )}
              {block.list && (
                <ul className="mt-4 flex list-disc flex-col gap-2 pl-6">
                  {block.list.map((item) => (
                    <li
                      key={item}
                      className="text-body font-normal text-carbon-warm/75"
                    >
                      {item}
                    </li>
                  ))}
                </ul>
              )}
            </section>
          ))}
        </div>
      </article>

      <ContactCTA />
    </>
  )
}
