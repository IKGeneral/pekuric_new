import { Link, useParams } from '@tanstack/react-router'
import PageHeader from '@/components/PageHeader'
import ContactCTA from '@/components/ContactCTA'
import SectionLabel from '@/components/SectionLabel'
import { getProjectBySlug } from '@/data/projects'

const metaFields = [
  ['Client', 'client'],
  ['Sector', 'sector'],
  ['Executing Agency', 'executingAgency'],
  ['Duration', 'duration'],
]

export default function ProjectDetail() {
  const { slug } = useParams({ from: '/_layout/our-projects/$slug' })
  const project = getProjectBySlug(slug)

  if (!project) {
    return null
  }

  const meta = metaFields.filter(([, key]) => project[key])

  return (
    <>
      <PageHeader
        label={project.category}
        title={project.title}
        intro={project.location}
      />

      <section className="container-t1 pb-24">
        <div className="aspect-[16/9] overflow-hidden rounded-card">
          <img
            src={project.image}
            alt={`${project.title}, ${project.category} project in ${project.location}`}
            className="h-full w-full object-cover"
          />
        </div>

        <div className="mt-14 grid gap-12 md:grid-cols-[2fr_1fr]">
          <p className="max-w-2xl text-body font-normal text-carbon-warm/80">
            {project.narrative}
          </p>

          {meta.length > 0 && (
            <dl className="grid grid-cols-2 gap-x-6 gap-y-6 self-start rounded-card border border-carbon-warm/15 p-8 md:grid-cols-1">
              {meta.map(([label, key]) => (
                <div key={key}>
                  <dt className="text-label font-normal uppercase tracking-[0.12em] text-carbon-warm/50">
                    {label}
                  </dt>
                  <dd className="mt-1 text-body-sm font-normal text-carbon-warm">
                    {project[key]}
                  </dd>
                </div>
              ))}
            </dl>
          )}
        </div>

        {project.gallery?.length > 0 && (
          <div className="mt-20">
            <SectionLabel>Project Gallery</SectionLabel>
            <div className="mt-8 columns-1 gap-4 sm:columns-2 lg:columns-3">
              {project.gallery.map((src, i) => (
                <div
                  key={src}
                  className="mb-4 break-inside-avoid overflow-hidden rounded-card"
                >
                  <img
                    src={src}
                    alt={`${project.title} in ${project.location}, photo ${i + 1}`}
                    className="w-full object-cover"
                    loading="lazy"
                  />
                </div>
              ))}
            </div>
          </div>
        )}

        <Link
          to="/our-projects"
          className="mt-14 inline-block text-body-sm font-normal text-carbon-warm/70 underline underline-offset-4 hover:text-carbon-warm"
        >
          ← Back to all projects
        </Link>
      </section>

      <ContactCTA />
    </>
  )
}
