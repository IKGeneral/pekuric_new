import { Link } from '@tanstack/react-router'
import PageHeader from '@/components/PageHeader'
import { termsPage } from '@/data/content'

export default function TermsAndConditions() {
  return (
    <>
      <PageHeader
        label={termsPage.label}
        title={termsPage.title}
        intro={termsPage.intro}
      />

      <section className="container-t1 pb-24">
        <p className="max-w-2xl text-body-sm font-normal text-carbon-warm/50">
          {termsPage.updated}
        </p>

        <div className="mt-12 flex flex-col gap-12 border-t border-carbon-warm/20 pt-12">
          {termsPage.sections.map((section) => (
            <div key={section.heading} className="max-w-2xl">
              <h2 className="text-heading font-light leading-tight tracking-[0.32px] text-carbon-warm">
                {section.heading}
              </h2>
              <p className="mt-4 text-body font-normal text-carbon-warm/75">
                {section.heading === 'Privacy' ? (
                  <>
                    Our collection and use of personal information submitted through this
                    website is governed by our{' '}
                    <Link
                      to="/privacy-policy"
                      className="underline underline-offset-4 hover:text-carbon-warm"
                    >
                      Privacy Policy
                    </Link>
                    .
                  </>
                ) : (
                  section.body
                )}
              </p>
            </div>
          ))}

          <div className="max-w-2xl">
            <h2 className="text-heading font-light leading-tight tracking-[0.32px] text-carbon-warm">
              {termsPage.contact.heading}
            </h2>
            <address className="mt-4 flex flex-col gap-1 text-body font-normal not-italic text-carbon-warm/75">
              <span>PEKURIC Limited</span>
              <span>{termsPage.contact.address}</span>
              <a
                href={`mailto:${termsPage.contact.email}`}
                className="transition-colors hover:text-carbon-warm"
              >
                {termsPage.contact.email}
              </a>
              {termsPage.contact.phones.map((phone) => (
                <a
                  key={phone}
                  href={`tel:${phone.replace(/[^+\d]/g, '')}`}
                  className="transition-colors hover:text-carbon-warm"
                >
                  {phone}
                </a>
              ))}
            </address>
          </div>
        </div>
      </section>
    </>
  )
}
