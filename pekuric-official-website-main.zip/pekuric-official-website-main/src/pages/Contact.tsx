import { useState } from 'react'
import { Link } from '@tanstack/react-router'
import PageHeader from '@/components/PageHeader'
import SectionLabel from '@/components/SectionLabel'
import { Button } from '@/components/ui/button'
import { Label } from '@/components/ui/label'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { contactPage } from '@/data/content'

export default function Contact() {
  const [submitted, setSubmitted] = useState(false)
  const { offices } = contactPage

  return (
    <>
      <PageHeader
        label={contactPage.label}
        title={contactPage.title}
        intro={contactPage.intro}
      />

      <section className="container-t1 pb-24">
        <div className="grid gap-16 md:grid-cols-12">
          {/* Form */}
          <div className="md:col-span-7">
            {submitted ? (
              <div className="rounded-[40px] border border-carbon-warm/20 bg-paper-white p-12">
                <SectionLabel>Message Sent</SectionLabel>
                <p className="mt-6 text-heading font-light leading-tight tracking-[0.32px] text-carbon-warm">
                  Thank you. We’ll be in touch shortly.
                </p>
              </div>
            ) : (
              <form
                className="flex flex-col gap-6"
                onSubmit={(e) => {
                  e.preventDefault()
                  const form = e.currentTarget
                  const { action, entries } = contactPage.googleForm
                  const body = new URLSearchParams()
                  for (const [field, entryId] of Object.entries(entries)) {
                    const input = form.elements.namedItem(field) as
                      | HTMLInputElement
                      | HTMLTextAreaElement
                      | null
                    body.append(entryId, input?.value ?? '')
                  }
                  fetch(action, {
                    method: 'POST',
                    mode: 'no-cors',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body,
                  }).finally(() => setSubmitted(true))
                }}
              >
                <div className="grid gap-6 sm:grid-cols-2">
                  {contactPage.fields.map((field) => (
                    <div key={field.name} className="flex flex-col gap-2">
                      <Label htmlFor={field.name}>
                        {field.label}
                        {field.required && (
                          <span className="text-carbon-warm/40"> *</span>
                        )}
                      </Label>
                      <Input
                        id={field.name}
                        name={field.name}
                        type={field.type}
                        required={field.required}
                      />
                    </div>
                  ))}
                </div>

                <div className="flex flex-col gap-2">
                  <Label htmlFor={contactPage.message.name}>
                    {contactPage.message.label}
                    {contactPage.message.required && (
                      <span className="text-carbon-warm/40"> *</span>
                    )}
                  </Label>
                  <Textarea
                    id={contactPage.message.name}
                    name={contactPage.message.name}
                    rows={6}
                    required={contactPage.message.required}
                  />
                </div>

                <div className="flex flex-col gap-4">
                  <p className="text-body-sm font-normal text-carbon-warm/60">
                    {contactPage.privacyNotice.replace('Privacy Policy', '')}
                    <Link
                      to="/privacy-policy"
                      className="underline underline-offset-4 hover:text-carbon-warm"
                    >
                      Privacy Policy
                    </Link>
                    .
                  </p>
                  <div>
                    <Button type="submit" variant="filled">
                      {contactPage.submit}
                    </Button>
                  </div>
                </div>
              </form>
            )}
          </div>

          {/* Details */}
          <aside className="md:col-span-5 md:pl-8">
            <div className="flex flex-col gap-8">
              {offices.map((office) => (
                <div
                  key={office.heading}
                  className="border-t border-carbon-warm/20 pt-8"
                >
                  <SectionLabel>{office.heading}</SectionLabel>
                  <address className="mt-6 flex flex-col gap-6 not-italic">
                    <p className="max-w-xs text-body font-normal text-carbon-warm/80">
                      {office.address}
                    </p>
                    <div className="flex flex-col gap-1">
                      <span className="text-label font-normal uppercase tracking-[0.12em] text-carbon-warm/50">
                        Email
                      </span>
                      <a
                        href={`mailto:${office.email}`}
                        className="text-body font-normal text-carbon-warm transition-colors hover:text-carbon-warm/60"
                      >
                        {office.email}
                      </a>
                    </div>
                    {office.phones.length > 0 && (
                      <div className="flex flex-col gap-1">
                        <span className="text-label font-normal uppercase tracking-[0.12em] text-carbon-warm/50">
                          Phone
                        </span>
                        {office.phones.map((phone) => (
                          <a
                            key={phone}
                            href={`tel:${phone.replace(/[^+\d]/g, '')}`}
                            className="text-body font-normal text-carbon-warm transition-colors hover:text-carbon-warm/60"
                          >
                            {phone}
                          </a>
                        ))}
                      </div>
                    )}
                  </address>
                </div>
              ))}
            </div>
          </aside>
        </div>
      </section>
    </>
  )
}
