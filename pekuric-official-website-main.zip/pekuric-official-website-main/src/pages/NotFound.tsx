import { Link } from '@tanstack/react-router'
import Nav from '@/components/Nav'
import Footer from '@/components/Footer'
import PageHeader from '@/components/PageHeader'
import { Button } from '@/components/ui/button'

type NotFoundProps = {
  withShell?: boolean
}

function NotFoundContent() {
  return (
    <>
      <PageHeader
        label="Page Not Found"
        title="This page does not exist."
        intro="Return to Pekuric Limited's homepage to explore our projects, services and company."
      >
        <div className="mt-10 flex flex-col gap-3 sm:flex-row">
          <Button asChild>
            <Link to="/">Go Home</Link>
          </Button>
          <Button asChild variant="ghost">
            <Link to="/our-projects">View Projects</Link>
          </Button>
        </div>
      </PageHeader>

      <section className="container-t1 pb-24">
        <div className="rounded-card border border-carbon-warm/15 bg-paper-white p-8">
          <p className="max-w-2xl text-body font-normal text-carbon-warm/75">
            The address may have changed, or the project you are looking for may no
            longer be available at this URL.
          </p>
        </div>
      </section>
    </>
  )
}

export default function NotFound({ withShell = false }: NotFoundProps) {
  if (!withShell) {
    return <NotFoundContent />
  }

  return (
    <div className="min-h-screen bg-vellum">
      <Nav />
      <main>
        <NotFoundContent />
      </main>
      <Footer />
    </div>
  )
}
