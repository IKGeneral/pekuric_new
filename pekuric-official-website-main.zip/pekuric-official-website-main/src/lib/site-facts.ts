/**
 * Single source of truth for public facts about Pekuric Limited.
 *
 * Read by the page head helper, the JSON-LD builders, the footer and contact
 * copy, and the build script that writes sitemap.xml and llms.txt. Keep this
 * file free of imports so the build script can load it with plain Node.
 *
 * Only state facts here that the site already publishes or the owner has
 * confirmed. Credentials, opening hours, coordinates and ratings are left out
 * on purpose until they are confirmed.
 */

export const SITE_URL = 'https://pekuric.com'

export const siteFacts = {
  name: 'Pekuric Limited',
  shortName: 'Pekuric',
  url: SITE_URL,
  foundingYear: '2017',
  summary:
    'Pekuric Limited is a civil engineering and construction company based in Benin City, Edo State, Nigeria, established in 2017. It delivers building construction, road construction, renovation, architecture and project management for government, corporate and private clients across Nigeria.',
  contact: {
    heading: 'Head Office',
    address:
      '1 Imaghodor Street, Off Oba Eweka Road, Ihama, GRA, Benin City, Edo State',
    street: '1 Imaghodor Street, Off Oba Eweka Road, Ihama, GRA',
    city: 'Benin City',
    region: 'Edo State',
    country: 'NG',
    email: 'info@pekuric.com',
    phones: ['+234 703 180 7117', '+234 805 300 6862'],
  },
  abujaOffice: {
    heading: 'Abuja Office',
    address: '50 Ebitu Ukiwe Street, Jabi, Abuja',
    street: '50 Ebitu Ukiwe Street, Jabi',
    city: 'Abuja',
  },
  sameAs: [
    'https://www.linkedin.com/company/pekuric-limited/',
    'https://www.instagram.com/pekuric_limited/',
  ],
  areaServed: [
    'Benin City',
    'Edo State',
    'South South Nigeria',
    'South West Nigeria',
    'Nigeria',
  ],
  // Service names as listed on the services page. Kept here so the build
  // script can write them to llms.txt without importing page content.
  serviceNames: [
    'Building Construction',
    'Road Construction',
    'Architecture',
    'Consulting',
    'Processing Facilities',
    'Management',
  ],
  serviceAreas: [
    'Building construction',
    'Road and civil works',
    'Renovation',
    'Architecture and project management',
  ],
  locale: 'en_NG',
}

/**
 * Pages that are indexed, in sitemap order. `trailingSlash` records the
 * canonical form for each path and matches what each route passes to seoHead.
 */
export const staticPages: { path: string; trailingSlash?: boolean }[] = [
  { path: '/' },
  { path: '/our-company' },
  { path: '/our-services' },
  { path: '/our-projects' },
  { path: '/contact-us' },
  { path: '/privacy-policy' },
  { path: '/terms-and-conditions' },
  { path: '/news-insights', trailingSlash: true },
  { path: '/category/construction', trailingSlash: true },
]

const stripTrailingSlash = (path: string) =>
  path === '/' ? path : path.replace(/\/$/, '')

const ensureTrailingSlash = (path: string) =>
  path.endsWith('/') ? path : `${path}/`

export const canonicalPath = (path: string, trailingSlash = false) =>
  trailingSlash ? ensureTrailingSlash(path) : stripTrailingSlash(path)

export const canonicalUrl = (path: string, trailingSlash = false) =>
  `${SITE_URL}${canonicalPath(path, trailingSlash)}`

export const absoluteUrl = (path: string) => {
  if (path.startsWith('http://') || path.startsWith('https://')) {
    return path
  }

  return `${SITE_URL}${path.startsWith('/') ? path : `/${path}`}`
}

export const slugify = (value: string) =>
  value
    .toLowerCase()
    .replace(/&/g, 'and')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
