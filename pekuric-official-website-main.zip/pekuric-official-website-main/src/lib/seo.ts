import {
  SITE_URL,
  absoluteUrl,
  canonicalUrl,
  siteFacts,
} from '@/lib/site-facts'

export { SITE_URL, absoluteUrl, canonicalUrl }

type JsonLd = Record<string, unknown>

type SeoHeadInput = {
  title: string
  description: string
  path: string
  image: string
  type?: 'website' | 'article'
  trailingSlash?: boolean
  /** Breadcrumb trail after Home, as [name, path] pairs. */
  breadcrumbs?: [string, string][]
  /** Extra JSON-LD nodes owned by the page (service, article, project). */
  jsonLd?: JsonLd[]
}

export const MAX_DESCRIPTION = 155

export const truncateDescription = (value: string, maxLength = MAX_DESCRIPTION) => {
  if (value.length <= maxLength) {
    return value
  }

  return `${value.slice(0, maxLength - 1).trimEnd()}…`
}

const ORGANIZATION_ID = `${SITE_URL}/#organization`
const WEBSITE_ID = `${SITE_URL}/#website`

export const organizationRef = { '@id': ORGANIZATION_ID }

const breadcrumbList = (
  trail: [string, string][],
  trailingSlash: boolean,
): JsonLd => ({
  '@context': 'https://schema.org',
  '@type': 'BreadcrumbList',
  itemListElement: [
    ['Home', '/'] as [string, string],
    ...trail,
  ].map(([name, path], index, all) => ({
    '@type': 'ListItem',
    position: index + 1,
    name,
    item: canonicalUrl(path, index === all.length - 1 ? trailingSlash : false),
  })),
})

export const seoHead = ({
  title,
  description,
  path,
  image,
  type = 'website',
  trailingSlash = false,
  breadcrumbs,
  jsonLd = [],
}: SeoHeadInput) => {
  const url = canonicalUrl(path, trailingSlash)
  const imageUrl = absoluteUrl(image)
  const nodes = [
    ...(breadcrumbs ? [breadcrumbList(breadcrumbs, trailingSlash)] : []),
    ...jsonLd,
  ]

  return {
    meta: [
      { title },
      { name: 'description', content: description },
      { property: 'og:site_name', content: siteFacts.name },
      { property: 'og:locale', content: siteFacts.locale },
      { property: 'og:title', content: title },
      { property: 'og:description', content: description },
      { property: 'og:image', content: imageUrl },
      { property: 'og:url', content: url },
      { property: 'og:type', content: type },
      { name: 'twitter:card', content: 'summary_large_image' },
      { name: 'twitter:title', content: title },
      { name: 'twitter:description', content: description },
      { name: 'twitter:image', content: imageUrl },
    ],
    links: [{ rel: 'canonical', href: url }],
    scripts: nodes.map((node) => ({
      type: 'application/ld+json',
      children: JSON.stringify(node),
    })),
  }
}

export const notFoundHead = () => ({
  meta: [
    { title: 'Page Not Found | Pekuric Limited' },
    {
      name: 'description',
      content:
        "The page you're looking for doesn't exist. Return to Pekuric Limited's homepage to explore our projects, services and company.",
    },
    { name: 'robots', content: 'noindex, follow' },
  ],
})

/**
 * Site wide graph: the company and the website. Emitted once, from the root
 * route. Only confirmed facts go in here.
 */
export const siteJsonLd: JsonLd = {
  '@context': 'https://schema.org',
  '@graph': [
    {
      '@type': 'GeneralContractor',
      '@id': ORGANIZATION_ID,
      name: siteFacts.name,
      legalName: siteFacts.name,
      url: SITE_URL,
      description: siteFacts.summary,
      image: absoluteUrl('/images/hero-poster.jpg'),
      foundingDate: siteFacts.foundingYear,
      email: siteFacts.contact.email,
      telephone: siteFacts.contact.phones[0],
      address: {
        '@type': 'PostalAddress',
        streetAddress: siteFacts.contact.street,
        addressLocality: siteFacts.contact.city,
        addressRegion: siteFacts.contact.region,
        addressCountry: siteFacts.contact.country,
      },
      location: [
        {
          '@type': 'Place',
          name: siteFacts.contact.heading,
          address: {
            '@type': 'PostalAddress',
            streetAddress: siteFacts.contact.street,
            addressLocality: siteFacts.contact.city,
            addressRegion: siteFacts.contact.region,
            addressCountry: siteFacts.contact.country,
          },
        },
        {
          '@type': 'Place',
          name: siteFacts.abujaOffice.heading,
          address: {
            '@type': 'PostalAddress',
            streetAddress: siteFacts.abujaOffice.street,
            addressLocality: siteFacts.abujaOffice.city,
            addressCountry: siteFacts.contact.country,
          },
        },
      ],
      areaServed: siteFacts.areaServed.map((name) => ({
        '@type': 'AdministrativeArea',
        name,
      })),
      knowsAbout: siteFacts.serviceAreas,
      sameAs: siteFacts.sameAs,
    },
    {
      '@type': 'WebSite',
      '@id': WEBSITE_ID,
      url: SITE_URL,
      name: siteFacts.name,
      inLanguage: 'en-NG',
      publisher: organizationRef,
    },
  ],
}

export const serviceJsonLd = (
  services: { title: string; body: string; id: string }[],
): JsonLd[] =>
  services.map((service) => ({
    '@context': 'https://schema.org',
    '@type': 'Service',
    '@id': `${SITE_URL}/our-services#${service.id}`,
    name: service.title,
    serviceType: service.title,
    description: service.body,
    url: `${SITE_URL}/our-services#${service.id}`,
    provider: organizationRef,
    areaServed: { '@type': 'Country', name: 'Nigeria' },
  }))

export const articleJsonLd = (article: {
  title: string
  excerpt: string
  image: string
  author: string
  publishDate: string
  url: string
}): JsonLd => ({
  '@context': 'https://schema.org',
  '@type': 'Article',
  headline: article.title,
  description: article.excerpt,
  image: absoluteUrl(article.image),
  datePublished: article.publishDate,
  author: organizationRef,
  publisher: organizationRef,
  mainEntityOfPage: article.url,
  inLanguage: 'en-NG',
})

export const projectJsonLd = (project: {
  slug: string
  title: string
  summary: string
  image: string
  location: string
  category: string
}): JsonLd => ({
  '@context': 'https://schema.org',
  '@type': 'CreativeWork',
  name: project.title,
  description: project.summary,
  url: canonicalUrl(`/our-projects/${project.slug}`),
  image: absoluteUrl(project.image),
  genre: project.category,
  contentLocation: { '@type': 'Place', name: project.location },
  creator: organizationRef,
  publisher: organizationRef,
  inLanguage: 'en-NG',
})

/**
 * Page title for a project: the location helps local search, but only when
 * the result still fits in 60 characters.
 */
export const projectTitle = (title: string, location: string) => {
  const withLocation = `${title}, ${location} | Pekuric`

  return withLocation.length <= 60 ? withLocation : `${title} | Pekuric Projects`
}
