/**
 * Single source of truth for every Pekuric project — used by the homepage
 * teaser, the /our-projects archive, and individual /our-projects/:slug
 * detail pages. Kept separate from content.js so this list can later be
 * swapped for a fetch against a headless CMS without touching any page
 * component.
 *
 * Fields left `null` have no confirmed source yet (the live site has no
 * detail page for that project) — fill them in here once available.
 */

const asset = (file) => `/images/${file}`

const gallery = (slug, count) =>
  Array.from({ length: count }, (_, i) =>
    asset(`projects/${slug}/${String(i + 1).padStart(2, '0')}.jpg`)
  )

export const projects = [
  {
    slug: 'benin-central-bus-terminal',
    title: 'Benin Central Bus Terminal',
    location: 'Obakhavbaye, Benin City',
    category: 'Transit Infrastructure',
    image: asset('project-bus-terminal.jpg'),
    summary:
      'A modern intercity bus terminal and central park anchoring the New Edo Line.',
    narrative:
      'Pekuric was engaged by the Edo State Government to execute Phase 2 of the Benin Central Bus Rapid Transit (BRT) Terminal project in Obakhavbaye, Benin City, following the successful delivery of Phase 1. The scope included construction of a gatehouse, perimeter fencing, interlock paving, pedestrian walkways, CCTV systems, and fire safety installations. Despite demolition challenges and inflation-driven cost fluctuations, the project was completed on schedule using lean construction methods, daily performance tracking, and efficient resource management. Although budget adjustments were required due to market inflation, the client expressed satisfaction with both the quality and delivery timeline. This strong performance led to a follow-up award for the Stella Obasanjo Bus Park and further reinforced Pekuric’s reputation for excellence, timeliness, and reliability in public infrastructure delivery.',
    client: 'Edo State Government',
    sector: 'Public Infrastructure',
    executingAgency: 'Edo State Transport Authority',
    duration: '9 Months',
    gallery: gallery('benin-central-bus-terminal', 15),
  },
  {
    slug: 'school-of-health-technology-benin-city',
    title: 'Edo State School of Health Technology',
    location: 'Dumez Road, Benin City',
    category: 'Educational Facility',
    image: asset('project-health-tech.jpg'),
    summary:
      'Renovation, remodelling and new construction of a full academic campus and external works.',
    narrative:
      'Pekuric was engaged by the Edo State Government to renovate, remodel, and construct key infrastructure at the School of Health Technology, Benin City. The scope encompassed a new academic building, security house, and essential external facilities, including a generator base, firefighting systems, refuse disposal, and a recreational area. Despite obstacles, the team delivered the academic building on time using a phased construction approach and efficient project management. The outcome resulted in client satisfaction and minimal budget adjustments, leading to expanded future work.',
    client: 'Edo State Government',
    sector: 'Education Infrastructure',
    executingAgency: 'Edo State Public Building and Maintenance Agency',
    duration: '6 Months',
    gallery: gallery('school-of-health-technology-benin-city', 9),
  },
  {
    slug: 'the-nigerian-observer',
    title: 'The Nigerian Observer',
    location: 'Obakhavbaye, Benin City',
    category: 'Media & Commercial',
    image: asset('project-observer.jpg'),
    summary:
      'Remodelling and external works for the Nigerian Observer newspaper and publishing house.',
    narrative:
      'Pekuric was commissioned by the Edo State Government to handle the renovation and construction of the Nigerian Observer Newspaper and Printing Complex (Phase 2) in Benin City. The 12-week project involved building a new administrative block, main and small printing houses, and external works, as well as demolishing outdated structures. Despite challenges with remote client involvement and a tight delivery schedule, Pekuric ensured smooth execution through phased delivery and improved communication channels. The project was delivered on time, with some overtime work added to accommodate additional client requests. The result was a significantly improved communications facility that enhanced public service delivery. The client expressed satisfaction with the quality and timeliness of the work, leading to a follow-up award for the Victor Uwaifo Creative Hub and external works. This project further cemented Pekuric’s reputation for reliability, execution speed, and construction excellence.',
    client: 'Edo State Government',
    sector: 'Communication Infrastructure',
    executingAgency: 'Edo State Transport Authority',
    duration: '12 Weeks',
    gallery: gallery('the-nigerian-observer', 8),
  },
  {
    slug: 'victor-uwaifo-creative-hub',
    title: 'Victor Uwaifo Creative Hub',
    location: 'Airport Road, Benin City',
    category: 'Creative & Cultural',
    image: asset('project-creative-hub.jpg'),
    summary:
      'Renovation of the Edo Creative Hub, a home for the state’s creative industries.',
    narrative:
      'Renovation of the Edo Creative Hub, a home for the state’s creative industries.',
    client: null,
    sector: null,
    executingAgency: null,
    duration: null,
    gallery: gallery('victor-uwaifo-creative-hub', 5),
  },
  {
    slug: 'south-south-innovation-hub',
    title: 'South-South Innovation Hub',
    location: 'Benin City, Edo State',
    category: 'Technology & Innovation',
    image: asset('project-innovation-hub.jpg'),
    summary:
      'A flagship innovation and startup campus for the Edo Innovates programme.',
    narrative:
      'A flagship innovation and startup campus for the Edo Innovates programme.',
    client: null,
    sector: null,
    executingAgency: null,
    duration: null,
    gallery: gallery('south-south-innovation-hub', 2),
  },
  {
    slug: '3-4km-obaretin-forest-reserve-road',
    title: '3.4km Obaretin Forest Reserve Road',
    location: 'Ikpoba-Okha, Edo State',
    category: 'Road Infrastructure',
    image: asset('project-obaretin-road.jpg'),
    summary:
      'Construction of a durable 3.4km asphalt road through the Obaretin corridor.',
    narrative:
      'Construction of a durable 3.4km asphalt road through the Obaretin corridor.',
    client: null,
    sector: null,
    executingAgency: null,
    duration: null,
    gallery: gallery('3-4km-obaretin-forest-reserve-road', 2),
  },
  {
    slug: 'ato-mills',
    title: 'Ato Mills',
    location: 'Edo State',
    category: 'Industrial Facility',
    image: asset('project-ato-mills.jpg'),
    summary:
      'Construction of reinforced-concrete tank foundations for an agro-processing mill.',
    narrative:
      'Pekuric was engaged by the Edo State Government to deliver reinforced-concrete tank foundation works for the Ato Mills processing facility. The scope covers excavation, rebar cage installation, and circular formwork and pour for a series of large-diameter concrete tanks forming the base of the processing plant.',
    client: 'Edo State Government',
    sector: 'Agro-Industrial Infrastructure',
    executingAgency: 'Edo State Government',
    duration: null,
    gallery: gallery('ato-mills', 5),
  },
  {
    slug: 'fidelity-bank-trans-amadi',
    title: 'Fidelity Bank, Trans Amadi',
    location: 'Port Harcourt, Rivers State',
    category: 'Commercial Building',
    image: asset('project-fidelity.jpg'),
    summary: 'Construction of a multi-storey commercial building for Fidelity Bank.',
    narrative:
      'Construction of a multi-storey commercial building for Fidelity Bank.',
    client: null,
    sector: null,
    executingAgency: null,
    duration: null,
    gallery: gallery('fidelity-bank-trans-amadi', 4),
  },
]

export const getProjectBySlug = (slug) =>
  projects.find((project) => project.slug === slug)
