/**
 * All site copy and imagery for Pekuric Limited. Copy is drawn from the
 * official Pekuric brochure and project photo-story. Project photos live in
 * /public/images (extracted from those documents).
 */

import { projects as allProjects } from '@/data/projects'
import { siteFacts, slugify } from '@/lib/site-facts'

const asset = (file) => `/images/${file}`

export const nav = {
  brand: 'Pekuric',
  links: [
    { label: 'Our Company', to: '/our-company' },
    { label: 'Our Services', to: '/our-services' },
    { label: 'Our Projects', to: '/our-projects' },
    { label: 'News & Insights', to: '/news-insights' },
  ],
  cta: { label: 'Contact Us', to: '/contact-us' },
}

export const hero = {
  headline: 'Reshaping the world,\none project at a time.',
  body: 'PEKURIC Limited is a civil engineering and construction firm in Benin City, Edo State, building the landmarks that shape communities across Nigeria: terminals, campuses, roads and processing plants.',
  cta: { label: "Let's Build Something Great", to: '/contact-us' },
  video: '/video/hero.mp4',
  poster: asset('hero-poster.jpg'),
  imageAlt: 'Construction site with a tower crane placing concrete',
  featured: {
    label: 'Featured Project',
    title: 'Benin Central Bus Terminal — New Edo Line',
    thumb: asset('project-bus-terminal.jpg'),
  },
}

export const about = {
  label: 'About Pekuric',
  headline:
    "We don't just build structures. We create landmarks that stand the test of time.",
  body: 'PEKURIC Limited is a civil engineering company redefining the architectural landscape through innovative, functional solutions in building and road construction, architecture and consulting. Our portfolio is truly multi-sectoral, spanning the private sector, public sector and international organisations: from multi-billion-naira public infrastructure to bespoke private builds, delivered on time and to the highest standard.',
  cta: { label: 'Learn More About Pekuric', to: '/our-company' },
}

export const stats = {
  label: 'By the Numbers',
  items: [
    { value: '2017', caption: 'Established in Benin City' },
    { value: '20+', caption: 'Units of owned plant & equipment' },
    { value: '8+', caption: 'Landmark projects delivered' },
    { value: '6', caption: 'Sectors served' },
  ],
  note: "Pekuric's safety performance is nearly 10× better than the industry average.",
}

/**
 * Client marquee. Six logos came from pekuric.com; the Edo and Ogun state seals
 * and the Nigerian Observer masthead were sourced separately (see
 * public/images/client-logos — provenance is noted in the project docs).
 * `logoClass` optically normalises each mark — the sources range from round
 * seals to ~4:1 mastheads, so a single height cap would leave the wide ones
 * dominant and the round ones looking undersized.
 */
export const clients = {
  label: 'Our Clients',
  headline: 'Trusted by government, industry and enterprise.',
  items: [
    {
      name: 'Nigerian Petroleum Development Company',
      logo: asset('client-logos/npdc.webp'),
      logoClass: 'max-h-20',
    },
    {
      name: 'Edo State Government',
      logo: asset('client-logos/edo-state-government.webp'),
      logoClass: 'max-h-20',
    },
    {
      name: 'Ogun State Government',
      logo: asset('client-logos/ogun-state-government.webp'),
      logoClass: 'max-h-20',
    },
    {
      name: 'The Nigerian Observer',
      logo: asset('client-logos/nigerian-observer.webp'),
    },
    {
      name: 'Saroafrica International',
      logo: asset('client-logos/saroafrica-international.webp'),
    },
    {
      name: 'A.G. Leventis (Nigeria) Ltd',
      logo: asset('client-logos/ag-leventis.webp'),
    },
    {
      name: 'Green Hills Agric Products',
      logo: asset('client-logos/greenhills.webp'),
    },
    {
      name: 'EdoJobs',
      logo: asset('client-logos/edojobs.webp'),
    },
  ],
}

export const imagePair = {
  images: [
    {
      src: asset('project-innovation-hub.jpg'),
      alt: 'Aerial view of the South-South Innovation Hub',
    },
    {
      src: asset('project-obaretin-road.jpg'),
      alt: 'Newly constructed asphalt road through a palm corridor',
    },
  ],
}

export const services = {
  label: 'Our Services',
  headline: 'Comprehensive civil engineering solutions.',
  intro:
    'From building and road construction to architecture, consulting and facility management, we deliver bespoke, innovative solutions that align with our clients’ visions.',
  render: asset('project-health-tech.jpg'),
  renderAlt: 'Completed academic building delivered by Pekuric',
  items: [
    {
      title: 'Building Construction',
      body: 'Skill, promptness and innovation are the hallmark of every building we deliver, fresh construction or revamp, tailor-made to the highest standards.',
    },
    {
      title: 'Road Construction',
      body: 'Our commitment to excellence shines on every road project. What shines brightest is our guarantee: the most durable roads, in record time.',
    },
    {
      title: 'Architecture',
      body: 'Our architects deliver brilliant designs that meet emerging global standards, grounded in a firm understanding of the structural requirements of each project.',
    },
    {
      title: 'Consulting',
      body: 'Modular solutions that help clients harness opportunities and maximise profit: feasibility studies, valuations, project management and project-specific consulting.',
    },
    {
      title: 'Processing Facilities',
      body: 'Construction and site-prep for processing facilities across agriculture, oil & gas and manufacturing, with a focus on sustainability and environmental responsibility.',
    },
    {
      title: 'Management',
      body: 'Expert builders make the best facility managers. We deliver maintenance and property management services to the highest standard.',
    },
  ],
}

const teaserSlugs = [
  'benin-central-bus-terminal',
  'school-of-health-technology-benin-city',
  'victor-uwaifo-creative-hub',
]

export const projects = {
  label: 'Our Projects',
  headline: 'A record of landmarks delivered.',
  cta: { label: 'See more of our work', to: '/our-projects' },
  cards: teaserSlugs.map((slug) =>
    allProjects.find((project) => project.slug === slug)
  ).filter((project) => project != null),
}

export const capabilities = {
  label: 'Plant & Capabilities',
  headline: 'An owned fleet that keeps us on schedule.',
  intro:
    'Pekuric operates an extensive fleet of heavy plant and equipment, so we mobilise fast, control quality on site, and deliver in record time without waiting on third parties.',
  groups: [
    {
      title: 'Earthmoving & Excavation',
      body: 'Caterpillar pay loaders and bulldozers, Komatsu and Fiat-Hitachi excavators, wheel excavators and motor graders.',
    },
    {
      title: 'Compaction & Paving',
      body: 'Vibratory rollers and compactors and a LeeBoy asphalt paver for durable, high-quality road surfaces.',
    },
    {
      title: 'Haulage & Lifting',
      body: 'Tipper and dump trucks, HIAB crane trucks, water tankers and low-loaders for continuous site logistics.',
    },
    {
      title: 'Concrete & Formwork',
      body: 'Concrete mixers and vibrators with modern formwork systems for precise, structural concrete work.',
    },
  ],
}

// Repurposed as the company mantra band.
export const testimonial = {
  label: 'Our Promise',
  quote: 'Until the client is satisfied, we are not done.',
  name: 'The Pekuric commitment',
  role: 'Reshaping the world, one project at a time',
}

export const careers = {
  label: 'Working at Pekuric',
  headline: 'Join Us in Building What Matters',
  body: 'Come build the assets and infrastructure that are integral to our everyday lives.',
  cta: { label: 'Learn More', to: '/contact-us' },
  image: asset('project-fidelity.jpg'),
  imageAlt: 'Pekuric project under construction',
}

export const footer = {
  brand: 'Pekuric',
  catchphrase: 'Redefining sustainable landscapes.',
  tagline:
    'A civil engineering and construction firm reshaping the world, one project at a time.',
  columns: [
    {
      heading: 'Sitemap',
      links: [
        { label: 'Our Company', to: '/our-company' },
        { label: 'Our Services', to: '/our-services' },
        { label: 'Our Projects', to: '/our-projects' },
        { label: 'News & Insights', to: '/news-insights' },
        { label: 'Contact Us', to: '/contact-us' },
      ],
    },
  ],
  /**
   * Rendered as brand-coloured icons in the footer's legal bar. `icon` keys map
   * to components in Footer.tsx — this file stays presentation-free.
   */
  socials: [
    {
      label: 'LinkedIn',
      href: 'https://www.linkedin.com/company/pekuric-limited/',
      icon: 'linkedin',
    },
    {
      label: 'Instagram',
      href: 'https://www.instagram.com/pekuric_limited/',
      icon: 'instagram',
    },
  ],
  contact: {
    heading: siteFacts.contact.heading,
    address: siteFacts.contact.address,
    email: siteFacts.contact.email,
    phones: siteFacts.contact.phones,
  },
  newsletter: {
    heading: 'Subscribe to Our Newsletter',
    placeholder: 'Email address',
    button: 'Subscribe',
    consent: 'I agree to receive marketing emails and to the Privacy Policy.',
  },
  legal: '© 2025 Pekuric Limited. All rights reserved.',
  legalLinks: [
    { label: 'Privacy Policy', to: '/privacy-policy' },
    { label: 'Terms & Conditions', to: '/terms-and-conditions' },
  ],
  builtBy: {
    label: 'Built by',
    href: 'https://weareserge.com',
    logo: asset('serge/logo.svg'),
    wordmark: asset('serge/wordmark-white.svg'),
  },
  legalSuffix: 'Pekuric Limited. All rights reserved.',
}

/* ------------------------------------------------------------------ *
 * Shared cross-page call-to-action band
 * ------------------------------------------------------------------ */
export const contactCTA = {
  label: 'Get in Touch',
  headline: 'Have a project in mind? Let’s build something great.',
  body: 'Reach out to our team and we’ll get back to you with the precision and accountability every build deserves.',
  cta: { label: "Let's Build Something Great", to: '/contact-us' },
}

/* ------------------------------------------------------------------ *
 * Our Company
 * ------------------------------------------------------------------ */
export const companyPage = {
  label: 'Our Company',
  title:
    'We don’t just build structures. We create landmarks that stand the test of time.',
  intro:
    'PEKURIC Limited is a civil engineering company in Nigeria, incorporated in 2017 and based in Benin City. We redefine the architectural landscape through innovative, functional solutions in building and road construction, architecture and consulting, for clients who value precision and accountability.',
  image: asset('project-health-tech.jpg'),
  imageAlt: 'A completed academic campus delivered by Pekuric',
  principles: {
    label: 'Vision, Mission & Culture',
    items: [
      {
        title: 'Vision',
        body: 'To create sustainable societies through infrastructure.',
      },
      {
        title: 'Mission',
        body: 'To put ideas, people and resources into influencing and creating defining landmarks across the globe.',
      },
      {
        title: 'Culture',
        body: 'Being passionate about delivering the highest standards is the heartbeat of our organisation.',
      },
    ],
  },
  values: {
    label: 'Core Values',
    intro:
      'Excellence, innovation, mastery and timeliness are the foundation of our work, ensuring every project is built with precision, reliability and lasting impact.',
    items: [
      {
        no: '01',
        title: 'Excellence',
        body: 'Delivering high-quality construction with precision and reliability.',
      },
      {
        no: '02',
        title: 'Innovation',
        body: 'Implementing smart engineering and modern solutions.',
      },
      {
        no: '03',
        title: 'Mastery',
        body: 'Backed by expertise, experience and technical proficiency.',
      },
      {
        no: '04',
        title: 'Timeliness',
        body: 'Ensuring on-time project delivery without compromising quality.',
      },
    ],
  },
  safety: {
    label: 'Safety First',
    headline: 'At Pekuric Limited, safety comes first.',
    body: 'We uphold strict safety standards, quality control and environmental responsibility to ensure secure worksites and successful project execution.',
    metric: '10×',
    metricCaption: 'better safety performance than the industry average',
  },
}

/* ------------------------------------------------------------------ *
 * Our Services
 * ------------------------------------------------------------------ */
export const servicesPage = {
  label: 'Our Services',
  title: 'Comprehensive civil engineering solutions.',
  intro:
    'PEKURIC provides end-to-end construction solutions for corporate developers, government agencies, international organisations and investors who demand precision, reliability and efficiency.',
  items: services.items.map((s, i) => ({
    id: slugify(s.title),
    no: String(i + 1).padStart(2, '0'),
    ...s,
  })),
  cta: {
    label: 'Talk to an Expert',
    body: 'Contact us to learn more about Pekuric’s capabilities.',
    button: 'Contact Us',
    to: '/contact-us',
  },
}

/* ------------------------------------------------------------------ *
 * Our Projects
 * ------------------------------------------------------------------ */
export const projectsPage = {
  label: 'Our Projects',
  title: 'A record of landmarks delivered.',
  intro:
    'Every project we take on is built with precision, expertise and a commitment to excellence. From transit infrastructure and public buildings to roads and commercial developments, we build with purpose and impact.',
  cards: allProjects.map((project) => ({
    slug: project.slug,
    title: project.title,
    location: project.location,
    category: project.category,
    image: project.image,
    description: project.summary,
  })),
}

/* ------------------------------------------------------------------ *
 * Contact Us
 * ------------------------------------------------------------------ */
export const contactPage = {
  label: 'Contact Us',
  title: 'Let’s build something great.',
  intro:
    'Thank you for your interest in PEKURIC Limited. For inquiries, provide your information below and our team will be in touch.',
  privacyNotice: 'By submitting this form, you agree to our Privacy Policy.',
  fields: [
    { name: 'name', label: 'Your Name', type: 'text', required: true },
    { name: 'email', label: 'Email', type: 'email', required: true },
    { name: 'location', label: 'Location', type: 'text' },
    { name: 'organisation', label: 'Organisation', type: 'text' },
  ],
  message: { name: 'message', label: 'Message', required: true },
  submit: 'Submit',
  googleForm: {
    action:
      'https://docs.google.com/forms/d/e/1FAIpQLSdebZEwOfvtV6jzkAjEbRamgJawAI7YtPqgjbArBTQq1LOiLA/formResponse',
    entries: {
      name: 'entry.898422369',
      email: 'entry.1071060713',
      location: 'entry.245942956',
      organisation: 'entry.297010667',
      message: 'entry.1216128278',
    },
  },
  offices: [
    {
      heading: siteFacts.contact.heading,
      address: siteFacts.contact.address,
      email: siteFacts.contact.email,
      phones: siteFacts.contact.phones,
    },
    {
      heading: siteFacts.abujaOffice.heading,
      address: siteFacts.abujaOffice.address,
      email: siteFacts.contact.email,
      phones: [],
    },
  ],
}

/* ------------------------------------------------------------------ *
 * Privacy Policy
 * ------------------------------------------------------------------ */
export const privacyPolicy = {
  label: 'Privacy Policy',
  title: 'Privacy Policy',
  updated: 'Effective Date: August 2, 2026',
  intro:
    'This policy explains how PEKURIC Limited collects, uses, and protects personal information submitted through this website, in accordance with the Nigeria Data Protection Act, 2023 (NDPA) and the Nigeria Data Protection Regulation.',
  sections: [
    {
      heading: 'Who We Are',
      body: 'PEKURIC Limited (\u201cPekuric,\u201d \u201cwe,\u201d \u201cus,\u201d or \u201cour\u201d) is a civil engineering and construction company registered in Nigeria and based at 1 Imaghodor Street, Off Oba Eweka Road, Ihama, GRA, Benin City, Edo State.',
    },
    {
      heading: 'Information We Collect',
      body: 'We collect personal information you choose to provide directly to us. Through the contact form we collect your name, email address, location, organisation (where provided), and the content of your message. Through the newsletter signup we collect your email address and your consent to receive marketing communications. We do not use cookies, analytics, or automated tracking technologies on this website at this time. If that changes, this policy will be updated accordingly before any such technology is deployed.',
    },
    {
      heading: 'How We Use Your Information',
      body: 'We use the information you provide to respond to inquiries submitted through the contact form, assess and follow up on project or business opportunities you raise with us, and, where you have opted in, send you occasional updates about Pekuric\u2019s projects and services by email. We do not use your information for any purpose beyond what you provided it for.',
    },
    {
      heading: 'Legal Basis for Processing',
      body: 'We process contact-form submissions on the basis of legitimate interest: responding to inquiries you have voluntarily initiated. We process newsletter email addresses on the basis of your explicit consent, given at the point of signup. You may withdraw that consent at any time (see \u201cYour Rights\u201d below).',
    },
    {
      heading: 'Data Retention',
      body: 'We retain contact-form submissions for as long as reasonably necessary to address your inquiry and for our legitimate business records, after which they are deleted. Newsletter email addresses are retained until you unsubscribe or withdraw consent.',
    },
    {
      heading: 'Sharing Your Information',
      body: 'We do not sell, rent, or trade your personal information. We do not share it with third parties except where required by law or to the extent necessary to operate this website (e.g. hosting infrastructure), and only under obligations of confidentiality consistent with this policy.',
    },
    {
      heading: 'Your Rights',
      body: 'Under the NDPA, you have the right to access the personal data we hold about you, request correction of inaccurate data, request deletion of your data, object to or restrict how we process your data, request a copy of your data in a portable format, and withdraw consent at any time. To exercise any of these rights, contact us at info@pekuric.com.',
    },
    {
      heading: 'Data Security',
      body: 'We take reasonable technical and organisational measures to protect the personal information you provide from unauthorised access, alteration, disclosure, or destruction.',
    },
    {
      heading: 'Changes to This Policy',
      body: 'We may update this policy from time to time to reflect changes in our practices or applicable law. The effective date above will be updated accordingly.',
    },
  ],
  contact: {
    heading: 'Contact Us',
    body: 'Questions about this policy or how we handle your data can be directed to:',
    address:
      '1 Imaghodor Street, Off Oba Eweka Road, Ihama, GRA, Benin City, Edo State',
    email: 'info@pekuric.com',
    phones: ['+234 703 180 7117', '+234 805 300 6862'],
  },
}

/* ------------------------------------------------------------------ *
 * Terms & Conditions
 * ------------------------------------------------------------------ */
export const termsPage = {
  label: 'Terms & Conditions',
  title: 'Terms & Conditions',
  updated: 'Effective Date: August 2, 2026',
  intro:
    'By accessing or using this website, you agree to be bound by these Terms & Conditions. If you do not agree, please do not use this website.',
  sections: [
    {
      heading: 'Use of This Website',
      body: 'This website is provided for the purpose of sharing information about PEKURIC Limited, our services, and our completed projects, and for enabling inquiries through our contact form. You agree to use this website only for lawful purposes and not to attempt to disrupt its operation, misuse the contact or newsletter forms, or access it in a manner inconsistent with these terms.',
    },
    {
      heading: 'Intellectual Property',
      body: 'All content on this website, including text, images, project photography, logos, and the Pekuric brand mark, is the property of PEKURIC Limited or its licensors and is protected by applicable intellectual property law. You may not reproduce, distribute, or use this content for commercial purposes without our prior written consent.',
    },
    {
      heading: 'No Warranty',
      body: 'This website and its content are provided \u201cas is.\u201d While we make reasonable efforts to keep information accurate and up to date, we make no warranties, express or implied, regarding the completeness, accuracy, or reliability of any content on this site.',
    },
    {
      heading: 'Limitation of Liability',
      body: 'To the fullest extent permitted by law, PEKURIC Limited shall not be liable for any indirect, incidental, or consequential damages arising from your use of, or inability to use, this website.',
    },
    {
      heading: 'Third-Party Links',
      body: 'This website may reference or link to third-party websites (for example, our social media profiles). We are not responsible for the content or practices of any third-party site.',
    },
    {
      heading: 'Privacy',
      body: 'Our collection and use of personal information submitted through this website is governed by our Privacy Policy.',
    },
    {
      heading: 'Governing Law',
      body: 'These terms are governed by the laws of the Federal Republic of Nigeria.',
    },
    {
      heading: 'Changes to These Terms',
      body: 'We may update these terms from time to time. Continued use of this website after changes are posted constitutes acceptance of the revised terms.',
    },
  ],
  contact: {
    heading: 'Contact Us',
    body: '',
    address:
      '1 Imaghodor Street, Off Oba Eweka Road, Ihama, GRA, Benin City, Edo State',
    email: 'info@pekuric.com',
    phones: ['+234 703 180 7117', '+234 805 300 6862'],
  },
}
