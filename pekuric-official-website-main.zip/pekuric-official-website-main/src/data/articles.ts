export type ArticleBodyBlock = {
  heading: string
  paragraph?: string
  list?: string[]
}

export type Article = {
  slug: string
  title: string
  category: string
  author: string
  publishDate: string
  excerpt: string
  image: string
  intro: string
  body: ArticleBodyBlock[]
}

export const articles: Article[] = [
  {
    slug: 'the-future-of-building-why-sustainable-construction-matters',
    title: 'The Future of Building: Why Sustainable Construction Matters',
    category: 'Construction',
    author: 'Pekuric Limited',
    publishDate: '2025-06-21',
    excerpt:
      "As the world focuses on climate change and resource conservation, sustainable construction has become more than a trend. It's a necessity.",
    image: '/images/hero-poster.jpg',
    intro:
      "As the world focuses on climate change and resource conservation, sustainable construction has become more than a trend. It's a necessity.",
    body: [
      {
        heading: 'What is Sustainable Construction?',
        paragraph:
          'This approach involves using eco-friendly materials, minimizing waste, and designing energy-efficient structures.',
      },
      {
        heading: 'Benefits of Building Green',
        list: [
          'Lower energy bills',
          'Healthier indoor air quality',
          'Reduced environmental impact',
          'Increased property value',
        ],
      },
      {
        heading: 'Materials Making a Difference',
        list: ['Recycled steel', 'Bamboo flooring', 'Low-VOC paints', 'Solar panels'],
      },
      {
        heading: 'Our Commitment to Sustainability',
        paragraph:
          'At Pekuric Limited, we incorporate green practices into every stage of construction, from planning to completion.',
      },
      {
        heading: 'Client Incentives & Government Policies',
        paragraph:
          'Many countries offer tax breaks or subsidies for green buildings. Reach out to learn what may apply to your project.',
      },
      {
        heading: 'Conclusion',
        paragraph:
          "Building sustainably is not just smart, it's responsible. Contact us to explore green building options for your next project.",
      },
    ],
  },
  {
    slug: 'how-to-choose-the-right-construction-company-for-your-project',
    title: 'How to Choose the Right Construction Company for Your Project',
    category: 'Construction',
    author: 'Pekuric Limited',
    publishDate: '2025-06-21',
    excerpt:
      'Choosing the right construction partner is critical for a successful project, whether residential, commercial, or industrial.',
    image: '/images/hero-poster.jpg',
    intro:
      "Choosing the right construction partner is critical for a successful project, whether residential, commercial, or industrial. Here's what to look for.",
    body: [
      {
        heading: 'Experience & Track Record',
        paragraph:
          "Check how long they've been in business and their portfolio of completed projects.",
      },
      {
        heading: 'Licensing & Insurance',
        paragraph:
          'Always confirm that the company is fully licensed and insured to protect yourself legally and financially.',
      },
      {
        heading: 'Client Reviews & Testimonials',
        paragraph:
          'Online reviews and client feedback can give you honest insights into their service quality.',
      },
      {
        heading: 'Transparent Pricing',
        paragraph:
          'Be wary of vague estimates. A trustworthy company provides clear, detailed quotes with no hidden fees.',
      },
      {
        heading: 'Communication',
        paragraph:
          'How well do they respond to your inquiries? A reliable company keeps you informed throughout the project.',
      },
      {
        heading: 'Quality of Materials Used',
        paragraph:
          "The best companies use high-grade materials and won't cut corners to save money.",
      },
      {
        heading: 'Conclusion',
        paragraph:
          "Don't settle when it comes to construction. At Pekuric Limited, we prioritize quality, transparency, and client satisfaction. Let's build your vision, right, from the start.",
      },
    ],
  },
  {
    slug: '7-signs-its-time-to-renovate-your-home',
    title: "7 Signs It's Time to Renovate Your Home",
    category: 'Construction',
    author: 'Pekuric Limited',
    publishDate: '2025-06-21',
    excerpt:
      "Your home should be a place of comfort and pride. But over time, even the best-built homes need updates. Here are 7 signs it's time to consider a home renovation.",
    image: '/images/hero-poster.jpg',
    intro:
      'Your home should be a place of comfort and pride. But over time, even the best-built homes need updates.',
    body: [
      {
        heading: '1. Outdated Design',
        paragraph: 'Interiors resembling early 2000s aesthetics warrant modernization.',
      },
      {
        heading: '2. Structural Issues',
        paragraph:
          'Wall or foundation cracks signal problems requiring professional intervention.',
      },
      {
        heading: '3. Elevated Utility Costs',
        paragraph: 'Aging insulation, windows, and HVAC systems drive expenses upward.',
      },
      {
        heading: '4. Space Limitations',
        paragraph:
          'Cramped kitchens, inadequate storage, or insufficient bathrooms suggest redesign opportunities.',
      },
      {
        heading: '5. Water-Related Deterioration',
        paragraph:
          'Stains, warped materials, and paint failure indicate moisture complications.',
      },
      {
        heading: '6. Life Circumstance Shifts',
        paragraph:
          'New family members or home-based work necessitate spatial adjustments.',
      },
      {
        heading: '7. Resale Preparation',
        paragraph:
          'Kitchen and bathroom upgrades enhance market appeal and property valuation.',
      },
      {
        heading: 'Conclusion',
        paragraph:
          "If any of this sounds familiar, consult with our construction team. We'll help transform your house into the home you want.",
      },
    ],
  },
]

export const getArticleBySlug = (slug: string) =>
  articles.find((article) => article.slug === slug)
