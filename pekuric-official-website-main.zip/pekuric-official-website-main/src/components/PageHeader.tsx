import SectionLabel from '@/components/SectionLabel'
import type { ReactNode } from 'react'

/**
 * Standard inner-page header: section label, whisper-light display title and
 * an optional intro paragraph. Top padding clears the floating nav pill.
 */
type PageHeaderProps = {
  label: ReactNode
  title: ReactNode
  intro?: ReactNode
  children?: ReactNode
}

export default function PageHeader({ label, title, intro, children }: PageHeaderProps) {
  return (
    <header className="container-t1 pb-16 pt-36 md:pb-24 md:pt-44">
      <SectionLabel>{label}</SectionLabel>
      <h1 className="mt-8 max-w-4xl text-[clamp(32px,5vw,52px)] font-light leading-none tracking-[0.52px] text-carbon-warm">
        {title}
      </h1>
      {intro && (
        <p className="mt-8 max-w-2xl text-body font-normal text-carbon-warm/80">
          {intro}
        </p>
      )}
      {children}
    </header>
  )
}
