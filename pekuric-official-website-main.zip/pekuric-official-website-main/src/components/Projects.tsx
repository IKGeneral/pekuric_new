import { Link } from '@tanstack/react-router'
import { Button } from '@/components/ui/button'
import SectionLabel from '@/components/SectionLabel'
import { projects } from '@/data/content'

/**
 * Image-forward project gallery. Each card is a full-bleed photo with the
 * signature rounded geometry; title and location sit beneath on the vellum.
 */
export default function Projects() {
  return (
    <section id="projects" className="container-t1 py-24">
      <div className="flex flex-col gap-6 md:flex-row md:items-end md:justify-between">
        <div>
          <SectionLabel>{projects.label}</SectionLabel>
          <h2 className="mt-6 max-w-2xl text-[clamp(30px,5vw,52px)] font-light leading-none tracking-[0.52px] text-carbon-warm">
            {projects.headline}
          </h2>
        </div>
        <Button asChild variant="ghost" className="hidden md:inline-flex">
          <Link to={projects.cta.to}>{projects.cta.label}</Link>
        </Button>
      </div>

      <div className="mt-12 grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
        {projects.cards.map((card) => (
          <Link
            key={card.slug}
            to="/our-projects/$slug"
            params={{ slug: card.slug }}
            className="group block"
          >
            <div className="aspect-[4/5] overflow-hidden rounded-[40px]">
              <img
                src={card.image}
                alt={`${card.title}, ${card.location}`}
                className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                loading="lazy"
              />
            </div>
            <h3 className="mt-5 text-subheading font-normal text-carbon-warm">
              {card.title}
            </h3>
            <p className="mt-1 text-body-sm font-normal text-carbon-warm/60">
              {card.location}
            </p>
          </Link>
        ))}
      </div>

      <div className="mt-12 md:hidden">
        <Button asChild variant="ghost" className="w-full">
          <Link to={projects.cta.to}>{projects.cta.label}</Link>
        </Button>
      </div>
    </section>
  )
}
