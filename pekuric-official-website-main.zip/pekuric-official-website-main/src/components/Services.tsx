import {
  Accordion,
  AccordionItem,
  AccordionTrigger,
  AccordionContent,
} from '@/components/ui/accordion'
import SectionLabel from '@/components/SectionLabel'
import { services } from '@/data/content'

export default function Services() {
  return (
    <section id="services" className="container-t1 py-24">
      <div className="grid gap-12 md:grid-cols-2 md:gap-16">
        {/* Left: intro + supporting image */}
        <div className="flex flex-col gap-8">
          <div>
            <SectionLabel>{services.label}</SectionLabel>
            <h2 className="mt-6 text-[clamp(30px,5vw,52px)] font-light leading-none tracking-[0.52px] text-carbon-warm">
              {services.headline}
            </h2>
            <p className="mt-6 max-w-md text-body font-normal text-carbon-warm/80">
              {services.intro}
            </p>
          </div>
          <div className="aspect-square max-w-md overflow-hidden rounded-card">
            <img
              src={services.render}
              alt={services.renderAlt}
              className="h-full w-full object-cover"
              loading="lazy"
            />
          </div>
        </div>

        {/* Right: services accordion */}
        <div className="md:pt-2">
          <Accordion
            type="single"
            collapsible
            defaultValue="service-0"
            className="border-t border-carbon-warm/60"
          >
            {services.items.map((item, i) => (
              <AccordionItem key={item.title} value={`service-${i}`}>
                <AccordionTrigger>{item.title}</AccordionTrigger>
                <AccordionContent>{item.body}</AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </div>
    </section>
  )
}
