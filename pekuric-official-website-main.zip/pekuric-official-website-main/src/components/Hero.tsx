import { Link } from '@tanstack/react-router'
import { Button } from '@/components/ui/button'
import SectionLabel from '@/components/SectionLabel'
import { hero } from '@/data/content'

export default function Hero() {
  return (
    <section id="top" className="relative min-h-svh w-full overflow-hidden">
      {/* Full-bleed construction video, looping and muted. The poster shows
          instantly and covers slow/failed loads. */}
      <video
        className="absolute inset-0 h-full w-full object-cover motion-reduce:hidden"
        src={hero.video}
        poster={hero.poster}
        autoPlay
        muted
        loop
        playsInline
        preload="metadata"
        aria-hidden="true"
      />
      {/* Static fallback for users who prefer reduced motion */}
      <img
        src={hero.poster}
        alt={hero.imageAlt}
        className="absolute inset-0 hidden h-full w-full object-cover motion-reduce:block"
      />
      {/* Minimal bottom scrim — keeps white text legible across the footage */}
      <div
        className="absolute inset-0 bg-linear-to-t from-onyx-depth/65 via-onyx-depth/15 to-onyx-depth/10"
        aria-hidden="true"
      />

      <div className="container-t1 relative flex min-h-svh flex-col justify-end pb-16 pt-40">
        <div className="flex flex-col items-start gap-10 md:flex-row md:items-end md:justify-between">
          {/* Headline + subtext + CTA */}
          <div className="max-w-2xl">
            <h1 className="whitespace-pre-line text-[clamp(34px,7vw,52px)] font-light leading-none tracking-[0.52px] text-paper-white">
              {hero.headline}
            </h1>
            <p className="mt-6 max-w-xl text-body font-normal text-paper-white/85">
              {hero.body}
            </p>
            <div className="mt-8">
              <Button asChild variant="onDark">
                <Link to={hero.cta.to}>{hero.cta.label}</Link>
              </Button>
            </div>
          </div>

          {/* Featured-project overlay card */}
          <Link
            to="/our-projects"
            className="flex w-full max-w-sm items-center gap-4 rounded-body bg-carbon-warm p-4 transition-transform duration-200 hover:-translate-y-1 md:w-80"
          >
            <div className="flex-1">
              <SectionLabel onDark>{hero.featured.label}</SectionLabel>
              <p className="mt-2 text-body-sm font-normal text-paper-white">
                {hero.featured.title}
              </p>
            </div>
            <img
              src={hero.featured.thumb}
              alt={hero.featured.title}
              className="h-14 w-14 shrink-0 rounded-small object-cover"
            />
          </Link>
        </div>
      </div>
    </section>
  )
}
