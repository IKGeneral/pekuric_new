import { Link } from '@tanstack/react-router'
import { Button } from '@/components/ui/button'
import SectionLabel from '@/components/SectionLabel'
import { about } from '@/data/content'

export default function About() {
  return (
    <section id="about" className="container-t1 py-24">
      <SectionLabel>{about.label}</SectionLabel>

      <div className="mt-8 grid gap-12 md:grid-cols-12">
        <h2 className="text-[clamp(30px,5vw,52px)] font-light leading-none tracking-[0.52px] text-carbon-warm md:col-span-7">
          {about.headline}
        </h2>

        <div className="flex flex-col items-start gap-8 md:col-span-5 md:pt-2">
          <p className="max-w-md text-body font-normal text-carbon-warm/80">
            {about.body}
          </p>
          <Button asChild variant="ghost">
            <Link to={about.cta.to}>{about.cta.label}</Link>
          </Button>
        </div>
      </div>
    </section>
  )
}
