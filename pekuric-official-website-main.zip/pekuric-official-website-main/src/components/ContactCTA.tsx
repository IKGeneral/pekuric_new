import { Link } from '@tanstack/react-router'
import { Button } from '@/components/ui/button'
import SectionLabel from '@/components/SectionLabel'
import { contactCTA } from '@/data/content'

/**
 * Shared cross-page CTA band — a Carbon Warm panel inviting contact.
 * Reused at the foot of the Company, Services, Projects and News pages.
 */
export default function ContactCTA() {
  return (
    <section className="container-t1 py-12">
      <div className="rounded-[48px] bg-carbon-warm px-8 py-16 text-paper-white md:px-16 md:py-20">
        <SectionLabel onDark>{contactCTA.label}</SectionLabel>
        <div className="mt-8 flex flex-col gap-8 md:flex-row md:items-end md:justify-between">
          <div className="max-w-2xl">
            <h2 className="text-[clamp(28px,4vw,44px)] font-light leading-tight tracking-[0.3px]">
              {contactCTA.headline}
            </h2>
            <p className="mt-4 max-w-lg text-body font-normal text-paper-white/70">
              {contactCTA.body}
            </p>
          </div>
          <Button asChild variant="onDark" className="shrink-0">
            <Link to={contactCTA.cta.to}>{contactCTA.cta.label}</Link>
          </Button>
        </div>
      </div>
    </section>
  )
}
