import { useState } from 'react'
import { Link } from '@tanstack/react-router'
import { Instagram, Linkedin } from 'lucide-react'
import { PekuricLogo } from '@/components/PekuricLogo'
import { footer } from '@/data/content'

const SOCIAL_ICONS = {
  linkedin: Linkedin,
  instagram: Instagram,
} as const

/**
 * Brand colours for the social marks. LinkedIn is a flat blue; Instagram's
 * identity is a gradient, so its stroke points at the <linearGradient> defined
 * once in the legal bar below.
 */
const SOCIAL_STROKE: Record<string, string> = {
  linkedin: '#0A66C2',
  instagram: 'url(#instagram-gradient)',
}

/**
 * Onyx Depth terminator — the only full-width dark surface, giving the page
 * a definitive end. Holds the sitemap, socials, contact block and newsletter.
 */
export default function Footer() {
  const [newsletterConsent, setNewsletterConsent] = useState(false)
  const currentYear = new Date().getFullYear()
  const [consentPrefix, consentSuffix = '.'] =
    footer.newsletter.consent.split('Privacy Policy')

  return (
    <footer
      id="footer"
      className="mt-24 rounded-t-card bg-onyx-depth pb-7.5 pt-20 text-paper-white"
    >
      <div className="container-t1">
        <div className="grid gap-12 md:grid-cols-12">
          {/* Brand + catchphrase + newsletter */}
          <div className="md:col-span-5">
            <Link to="/" aria-label={`${footer.brand} — home`}>
              <PekuricLogo markClassName="h-10 w-auto" />
            </Link>
            <p className="mt-5 text-subheading font-light tracking-[0.22px] text-paper-white/90">
              {footer.catchphrase}
            </p>
            <p className="mt-3 max-w-xs text-body-sm font-normal text-paper-white/55">
              {footer.tagline}
            </p>

            <form
              className="mt-8 max-w-sm"
              onSubmit={(e) => e.preventDefault()}
            >
              <label
                htmlFor="footer-newsletter-email"
                className="text-label font-normal uppercase tracking-[0.12em] text-paper-white/50"
              >
                {footer.newsletter.heading}
              </label>
              <div className="mt-3 flex items-center gap-2 rounded-pill border border-paper-white/20 p-1 pl-5">
                <input
                  id="footer-newsletter-email"
                  type="email"
                  required
                  placeholder={footer.newsletter.placeholder}
                  className="w-full bg-transparent text-body-sm text-paper-white placeholder:text-paper-white/40 focus:outline-none"
                />
                <button
                  type="submit"
                  disabled={!newsletterConsent}
                  className="shrink-0 rounded-pill bg-paper-white px-5 py-2 text-body-sm font-normal text-carbon-warm transition-colors hover:bg-vellum disabled:cursor-not-allowed disabled:opacity-40"
                >
                  {footer.newsletter.button}
                </button>
              </div>
              <label className="mt-3 flex items-start gap-2 text-label font-normal text-paper-white/50">
                <input
                  type="checkbox"
                  required
                  checked={newsletterConsent}
                  onChange={(e) => setNewsletterConsent(e.target.checked)}
                  className="mt-0.5 h-3.5 w-3.5 shrink-0 rounded-small border border-paper-white/40 bg-transparent"
                />
                <span>
                  {consentPrefix}
                  <Link
                    to="/privacy-policy"
                    className="underline underline-offset-2 hover:text-paper-white"
                  >
                    Privacy Policy
                  </Link>
                  {consentSuffix}
                </span>
              </label>
            </form>
          </div>

          {/* Link columns — widened to col-span-3 now that the socials moved
              out of a column of their own and into the legal bar below. */}
          {footer.columns.map((column) => (
            <div key={column.heading} className="md:col-span-3">
              <h4 className="text-label font-normal uppercase tracking-[0.12em] text-paper-white/50">
                {column.heading}
              </h4>
              <ul className="mt-4 flex flex-col gap-3">
                {column.links.map((link) => (
                  <li key={link.label}>
                    <Link
                      to={link.to}
                      className="text-body-sm font-normal text-paper-white/85 transition-colors hover:text-paper-white"
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}

          {/* Contact block */}
          <div className="md:col-span-4">
            <h4 className="text-label font-normal uppercase tracking-[0.12em] text-paper-white/50">
              {footer.contact.heading}
            </h4>
            <address className="mt-4 flex flex-col gap-3 text-body-sm font-normal not-italic text-paper-white/85">
              <span className="text-paper-white/60">{footer.contact.address}</span>
              <a
                href={`mailto:${footer.contact.email}`}
                className="transition-colors hover:text-paper-white"
              >
                {footer.contact.email}
              </a>
              {footer.contact.phones.map((phone) => (
                <a
                  key={phone}
                  href={`tel:${phone.replace(/[^+\d]/g, '')}`}
                  className="transition-colors hover:text-paper-white"
                >
                  {phone}
                </a>
              ))}
            </address>
          </div>
        </div>

        <div className="mt-16 flex flex-col gap-6 border-t border-paper-white/10 pt-8 md:flex-row md:items-center md:justify-between">
          <div className="flex flex-wrap items-center gap-x-4 gap-y-2">
            <p className="text-label font-normal text-paper-white/40">
              {`\u00A9 ${currentYear} ${footer.legalSuffix}`}
            </p>
            {footer.legalLinks.map((link) => (
              <Link
                key={link.to}
                to={link.to}
                className="text-label font-normal text-paper-white/40 underline underline-offset-2 transition-colors hover:text-paper-white/70"
              >
                {link.label}
              </Link>
            ))}
          </div>

          {/* Social marks, in brand colour */}
          <div className="flex items-center gap-4">
            <svg aria-hidden="true" focusable="false" className="absolute h-0 w-0">
              <defs>
                <linearGradient id="instagram-gradient" x1="0%" y1="100%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#FFDC80" />
                  <stop offset="25%" stopColor="#F58529" />
                  <stop offset="50%" stopColor="#DD2A7B" />
                  <stop offset="75%" stopColor="#8134AF" />
                  <stop offset="100%" stopColor="#515BD4" />
                </linearGradient>
              </defs>
            </svg>

            {footer.socials.map((social) => {
              const Icon = SOCIAL_ICONS[social.icon as keyof typeof SOCIAL_ICONS]

              return (
                <a
                  key={social.label}
                  href={social.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label={`Pekuric on ${social.label}`}
                  className="opacity-80 transition-opacity hover:opacity-100"
                >
                  <Icon
                    className="h-5 w-5"
                    style={{ stroke: SOCIAL_STROKE[social.icon] }}
                    aria-hidden="true"
                  />
                </a>
              )
            })}
          </div>

          <a
            href={footer.builtBy.href}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-2 text-paper-white/40 transition-colors hover:text-paper-white/70"
          >
            <span className="text-label font-normal">{footer.builtBy.label}</span>
            <img src={footer.builtBy.logo} alt="" className="h-4 w-auto" />
            <img src={footer.builtBy.wordmark} alt="Serge" className="h-3 w-auto" />
          </a>
        </div>
      </div>
    </footer>
  )
}
