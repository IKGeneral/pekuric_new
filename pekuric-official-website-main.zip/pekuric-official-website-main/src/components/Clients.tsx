import SectionLabel from '@/components/SectionLabel'
import { clients } from '@/data/content'

/**
 * Client marquee — a slow, continuous drift that pauses on hover, with the
 * logos in full brand colour. The track renders the list twice so the -50%
 * translation loops seamlessly; the second pass is aria-hidden so screen
 * readers hear each client once. Honours prefers-reduced-motion.
 */
export default function Clients() {
  return (
    <section className="container-t1 py-16">
      <SectionLabel>{clients.label}</SectionLabel>
      <h2 className="mt-6 max-w-2xl text-[clamp(24px,3.5vw,40px)] font-light leading-tight tracking-[0.32px] text-carbon-warm">
        {clients.headline}
      </h2>

      <div
        className="group mt-12 overflow-hidden [mask-image:linear-gradient(to_right,transparent,black_8%,black_92%,transparent)]"
        aria-label="Our clients"
      >
        <div className="flex w-max animate-marquee items-center group-hover:[animation-play-state:paused] motion-reduce:animate-none">
          {[0, 1].map((pass) => (
            <ul
              key={pass}
              className="flex shrink-0 items-center"
              aria-hidden={pass === 1 || undefined}
            >
              {clients.items.map((client) => (
                <li
                  key={client.name}
                  className="flex shrink-0 items-center justify-center px-10 sm:px-14"
                >
                  <img
                    src={client.logo}
                    alt={pass === 0 ? client.name : ''}
                    loading="lazy"
                    className={`w-auto object-contain ${client.logoClass ?? 'max-h-14'}`}
                  />
                </li>
              ))}
            </ul>
          ))}
        </div>
      </div>
    </section>
  )
}
