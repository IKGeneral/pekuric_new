import * as React from 'react'
import * as AccordionPrimitive from '@radix-ui/react-accordion'
import { cn } from '@/lib/utils'

/**
 * shadcn/ui Accordion (Radix) restyled to the T1 tech-stack pattern:
 * hairline-separated rows, Carbon label on the left, and a 40px circular
 * +/- button on the right (the vertical bar collapses on open → minus).
 */
const Accordion = AccordionPrimitive.Root

const AccordionItem = React.forwardRef<
  React.ElementRef<typeof AccordionPrimitive.Item>,
  React.ComponentPropsWithoutRef<typeof AccordionPrimitive.Item>
>(({ className, ...props }, ref) => (
  <AccordionPrimitive.Item
    ref={ref}
    className={cn('border-b border-carbon-warm/60', className)}
    {...props}
  />
))
AccordionItem.displayName = 'AccordionItem'

const AccordionTrigger = React.forwardRef<
  React.ElementRef<typeof AccordionPrimitive.Trigger>,
  React.ComponentPropsWithoutRef<typeof AccordionPrimitive.Trigger>
>(
  ({ className, children, ...props }, ref) => (
    <AccordionPrimitive.Header className="flex">
      <AccordionPrimitive.Trigger
        ref={ref}
        className={cn(
          'group flex flex-1 items-center justify-between gap-4 py-6 text-left text-subheading font-normal text-carbon-warm transition-colors',
          className,
        )}
        {...props}
      >
        <span>{children}</span>
        {/* +/- indicator */}
        <span className="relative flex h-10 w-10 shrink-0 items-center justify-center rounded-pill border border-carbon-warm bg-paper-white transition-colors group-hover:bg-vellum">
          <span className="absolute h-px w-3.5 bg-carbon-warm" />
          <span className="absolute h-3.5 w-px bg-carbon-warm transition-transform duration-200 group-data-[state=open]:scale-y-0" />
        </span>
      </AccordionPrimitive.Trigger>
    </AccordionPrimitive.Header>
  ),
)
AccordionTrigger.displayName = 'AccordionTrigger'

const AccordionContent = React.forwardRef<
  React.ElementRef<typeof AccordionPrimitive.Content>,
  React.ComponentPropsWithoutRef<typeof AccordionPrimitive.Content>
>(
  ({ className, children, ...props }, ref) => (
    <AccordionPrimitive.Content
      ref={ref}
      className="overflow-hidden data-[state=closed]:animate-accordion-up data-[state=open]:animate-accordion-down"
      {...props}
    >
      <div className={cn('max-w-xl pb-6 text-body text-carbon-warm/80', className)}>
        {children}
      </div>
    </AccordionPrimitive.Content>
  ),
)
AccordionContent.displayName = 'AccordionContent'

export { Accordion, AccordionItem, AccordionTrigger, AccordionContent }
