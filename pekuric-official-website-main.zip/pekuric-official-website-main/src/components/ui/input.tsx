import * as React from 'react'
import { cn } from '@/lib/utils'

/** shadcn/ui Input — hairline-outlined field on Paper White, T1 styling. */
const Input = React.forwardRef<HTMLInputElement, React.InputHTMLAttributes<HTMLInputElement>>(({ className, type = 'text', ...props }, ref) => (
  <input
    ref={ref}
    type={type}
    className={cn(
      'w-full rounded-small border border-carbon-warm/25 bg-paper-white px-4 py-3 text-body-sm text-carbon-warm transition-colors placeholder:text-mercury focus:border-carbon-warm focus:outline-none disabled:cursor-not-allowed disabled:opacity-50',
      className,
    )}
    {...props}
  />
))
Input.displayName = 'Input'

export { Input }
