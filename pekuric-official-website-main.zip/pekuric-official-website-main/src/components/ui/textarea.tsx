import * as React from 'react'
import { cn } from '@/lib/utils'

/** shadcn/ui Textarea — matches the Input styling with a taller field. */
const Textarea = React.forwardRef<HTMLTextAreaElement, React.TextareaHTMLAttributes<HTMLTextAreaElement>>(({ className, ...props }, ref) => (
  <textarea
    ref={ref}
    className={cn(
      'w-full rounded-small border border-carbon-warm/25 bg-paper-white px-4 py-3 text-body-sm text-carbon-warm transition-colors placeholder:text-mercury focus:border-carbon-warm focus:outline-none disabled:cursor-not-allowed disabled:opacity-50',
      className,
    )}
    {...props}
  />
))
Textarea.displayName = 'Textarea'

export { Textarea }
