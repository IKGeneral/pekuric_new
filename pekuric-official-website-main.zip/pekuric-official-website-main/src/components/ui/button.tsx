import * as React from 'react'
import { Slot } from '@radix-ui/react-slot'
import { cva } from 'class-variance-authority'
import type { VariantProps } from 'class-variance-authority'
import { cn } from '@/lib/utils'

/**
 * shadcn/ui Button, restyled to the T1 Energy system.
 * - filled  → Carbon Warm pill, white text (primary action)
 * - ghost   → transparent, 1px Carbon border (secondary action)
 * Both share the 100px pill geometry and 18px/22px padding from the spec.
 */
const buttonVariants = cva(
  'inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-pill text-body-sm font-normal tracking-[0.14px] transition-colors duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-carbon-warm focus-visible:ring-offset-2 focus-visible:ring-offset-vellum disabled:pointer-events-none disabled:opacity-50',
  {
    variants: {
      variant: {
        filled: 'bg-carbon-warm text-paper-white hover:bg-onyx-depth',
        ghost:
          'border border-carbon-warm bg-transparent text-carbon-warm hover:bg-carbon-warm hover:text-paper-white',
        onDark:
          'bg-paper-white text-carbon-warm hover:bg-vellum',
      },
      size: {
        default: 'px-[22px] py-[18px]',
        sm: 'px-[18px] py-[12px]',
      },
    },
    defaultVariants: {
      variant: 'filled',
      size: 'default',
    },
  },
)

type ButtonProps = React.ButtonHTMLAttributes<HTMLButtonElement> &
  VariantProps<typeof buttonVariants> & {
    asChild?: boolean
  }

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : 'button'
    return (
      <Comp
        ref={ref}
        className={cn(buttonVariants({ variant, size, className }))}
        {...props}
      />
    )
  },
)
Button.displayName = 'Button'

export { Button, buttonVariants }
