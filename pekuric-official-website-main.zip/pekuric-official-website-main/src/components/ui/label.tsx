import * as React from 'react'
import { cn } from '@/lib/utils'

/** shadcn/ui Label — tiny uppercase form label in the T1 system. */
const Label = React.forwardRef<HTMLLabelElement, React.LabelHTMLAttributes<HTMLLabelElement>>(({ className, ...props }, ref) => (
  <label
    ref={ref}
    className={cn(
      'text-label font-normal uppercase tracking-[0.12em] text-carbon-warm/70',
      className,
    )}
    {...props}
  />
))
Label.displayName = 'Label'

export { Label }
