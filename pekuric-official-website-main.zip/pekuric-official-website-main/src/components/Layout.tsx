import { useEffect } from 'react'
import { Outlet, useLocation } from '@tanstack/react-router'
import Nav from '@/components/Nav'
import Footer from '@/components/Footer'

/** Reset scroll to top whenever the route changes. */
function ScrollToTop() {
  const { pathname } = useLocation()
  useEffect(() => {
    window.scrollTo(0, 0)
  }, [pathname])
  return null
}

export default function Layout() {
  return (
    <div className="min-h-screen bg-vellum">
      <ScrollToTop />
      <Nav />
      <main>
        <Outlet />
      </main>
      <Footer />
    </div>
  )
}
