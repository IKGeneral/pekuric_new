import { useState } from 'react'
import { Link } from '@tanstack/react-router'
import { Menu } from 'lucide-react'
import { Sheet, SheetTrigger, SheetContent, SheetClose } from '@/components/ui/sheet'
import { Button } from '@/components/ui/button'
import { PekuricMark } from '@/components/PekuricLogo'
import { nav } from '@/data/content'

type BrandProps = {
  className?: string
  onLight?: boolean
}

function Brand({ className, onLight = false }: BrandProps) {
  // Brand mark + Pekuric wordmark. On the vellum segment the mark renders in
  // the true brand palette; otherwise it inherits currentColor (white on dark).
  return (
    <Link
      to="/"
      className={`inline-flex items-center gap-2.5 ${className ?? ''}`}
      aria-label={`${nav.brand} — home`}
    >
      <PekuricMark className="h-6 w-auto" colored={onLight} />
      <span
        className={`text-[19px] font-normal uppercase leading-none tracking-[0.2em] ${
          onLight ? 'text-carbon-warm' : ''
        }`}
      >
        {nav.brand}
      </span>
    </Link>
  )
}

export default function Nav() {
  const [open, setOpen] = useState(false)

  return (
    <header className="pointer-events-none fixed inset-x-0 top-0 z-40">
      <div className="container-t1 flex justify-center pt-6 md:justify-end">
        {/* Floating pill — vellum brand segment butted against the dark body.
            Padding lives on the segments, not the pill, so the light block can
            bleed to the edge; overflow-hidden lets rounded-nav clip its corners. */}
        <nav className="pointer-events-auto flex w-full items-stretch overflow-hidden rounded-nav bg-carbon-warm text-paper-white md:w-auto">
          <div className="flex items-center bg-vellum px-5">
            <Brand onLight />
          </div>

          <div className="flex flex-1 items-center justify-end gap-6 px-6 py-4 md:py-[18px]">
            {/* Desktop links */}
            <ul className="hidden items-center gap-6 md:flex">
              {nav.links.map((link) => (
                <li key={link.label}>
                  <Link
                    to={link.to}
                    className="text-body-sm font-normal transition-colors hover:text-paper-white"
                    activeProps={{ className: 'text-paper-white' }}
                    inactiveProps={{ className: 'text-paper-white/70' }}
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>

            <Link
              to={nav.cta.to}
              className="hidden rounded-pill bg-paper-white px-5 py-2 text-body-sm font-normal text-carbon-warm transition-colors hover:bg-vellum md:inline-block"
            >
              {nav.cta.label}
            </Link>

            {/* Mobile trigger */}
            <Sheet open={open} onOpenChange={setOpen}>
              <SheetTrigger asChild>
                <button
                  className="inline-flex items-center justify-center rounded-pill p-1 text-paper-white md:hidden"
                  aria-label="Open menu"
                >
                  <Menu className="h-6 w-6" />
                </button>
              </SheetTrigger>
              <SheetContent>
                {/* Left-anchored vellum block: keeps the brand identical to the
                    desktop pill while leaving the close button on carbon. */}
                <div className="-ml-8 -mt-8 mr-auto bg-vellum px-8 py-6">
                  <Brand onLight />
                </div>
                <ul className="flex flex-col gap-6">
                  {nav.links.map((link) => (
                    <li key={link.label}>
                      <SheetClose asChild>
                        <Link
                          to={link.to}
                          className="text-heading font-light text-paper-white/90 transition-colors hover:text-paper-white"
                        >
                          {link.label}
                        </Link>
                      </SheetClose>
                    </li>
                  ))}
                </ul>
                <SheetClose asChild>
                  <Button asChild variant="onDark" className="mt-auto w-full">
                    <Link to={nav.cta.to}>{nav.cta.label}</Link>
                  </Button>
                </SheetClose>
              </SheetContent>
            </Sheet>
          </div>
        </nav>
      </div>
    </header>
  )
}
