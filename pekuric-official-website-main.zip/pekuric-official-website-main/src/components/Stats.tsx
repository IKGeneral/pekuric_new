import SectionLabel from '@/components/SectionLabel'
import { stats } from '@/data/content'

/**
 * Specification-sheet stats band: whisper-light display numerals over tiny
 * captions, separated from the note by a hairline. Flat, no shadows.
 */
export default function Stats() {
  return (
    <section className="container-t1 py-16">
      <SectionLabel>{stats.label}</SectionLabel>

      <div className="mt-10 grid gap-12 border-t border-carbon-warm/20 pt-12 sm:grid-cols-3">
        {stats.items.map((stat) => (
          <div key={stat.caption}>
            <div className="text-[clamp(40px,6vw,52px)] font-light leading-none tracking-[0.52px] text-carbon-warm">
              {stat.value}
            </div>
            <p className="mt-3 text-body-sm font-normal text-carbon-warm/70">
              {stat.caption}
            </p>
          </div>
        ))}
      </div>

      <p className="mt-12 max-w-2xl border-t border-carbon-warm/20 pt-8 text-body font-normal text-carbon-warm/70">
        {stats.note}
      </p>
    </section>
  )
}
