import SectionLabel from '@/components/SectionLabel'
import { capabilities } from '@/data/content'

/**
 * Plant & capabilities — a Carbon Warm band listing the owned equipment
 * categories that let Pekuric mobilise fast and control quality on site.
 */
export default function Capabilities() {
  return (
    <section className="container-t1 py-12">
      <div className="rounded-[48px] bg-carbon-warm px-8 py-16 text-paper-white md:px-16 md:py-20">
        <div className="grid gap-6 md:grid-cols-12 md:items-end">
          <div className="md:col-span-7">
            <SectionLabel onDark>{capabilities.label}</SectionLabel>
            <h2 className="mt-6 text-[clamp(28px,4vw,44px)] font-light leading-tight tracking-[0.3px]">
              {capabilities.headline}
            </h2>
          </div>
          <p className="text-body font-normal text-paper-white/70 md:col-span-5">
            {capabilities.intro}
          </p>
        </div>

        <div className="mt-14 grid gap-x-10 gap-y-10 border-t border-paper-white/15 pt-12 sm:grid-cols-2">
          {capabilities.groups.map((group) => (
            <div key={group.title} className="flex gap-5">
              <span className="mt-1 h-1 w-1 shrink-0 bg-paper-white/60" aria-hidden="true" />
              <div>
                <h3 className="text-subheading font-normal text-paper-white">
                  {group.title}
                </h3>
                <p className="mt-2 max-w-md text-body-sm font-normal text-paper-white/65">
                  {group.body}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
