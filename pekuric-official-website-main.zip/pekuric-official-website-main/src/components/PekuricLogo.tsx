/**
 * Pekuric brand mark — reconstructed as vector from the supplied logo art.
 * Two maroon uprights + a gray "L" (right upright + base), even gaps.
 *
 * `colored` renders the true brand palette (#6a0002 maroon / #6f7277 gray) for
 * light surfaces — the vellum brand segment of the nav pill, the matching block
 * in the mobile sheet, and the favicon. Otherwise every shape uses
 * `currentColor`, so the mark inherits the surrounding text color — e.g. white
 * on the onyx footer. Note the maroon is near-black: it needs a light surface,
 * as it is effectively invisible against carbon-warm or onyx.
 */
type PekuricMarkProps = {
  className?: string
  colored?: boolean
  title?: string
}

type PekuricLogoProps = {
  className?: string
  markClassName?: string
  showLimited?: boolean
}

export function PekuricMark({ className, colored = false, title = 'Pekuric' }: PekuricMarkProps) {
  const maroon = colored ? '#6a0002' : 'currentColor'
  const gray = colored ? '#6f7277' : 'currentColor'
  return (
    <svg
      viewBox="0 0 1608 1512"
      className={className}
      role="img"
      aria-label={title}
      xmlns="http://www.w3.org/2000/svg"
    >
      <rect x="0" y="0" width="480" height="1512" fill={maroon} />
      <rect x="558" y="0" width="480" height="1020" fill={maroon} />
      <rect x="1122" y="0" width="486" height="1512" fill={gray} />
      <rect x="558" y="1104" width="564" height="408" fill={gray} />
    </svg>
  )
}

/**
 * Full lockup: the mark beside the PEKURIC / LIMITED wordmark. Inherits text
 * color for use on dark surfaces. `showLimited` toggles the second line.
 */
export function PekuricLogo({ className, markClassName, showLimited = true }: PekuricLogoProps) {
  return (
    <span className={`inline-flex items-center gap-3 ${className ?? ''}`}>
      <PekuricMark className={markClassName ?? 'h-8 w-auto'} />
      <span className="flex flex-col leading-none">
        <span className="text-[20px] font-normal uppercase tracking-[0.2em]">
          Pekuric
        </span>
        {showLimited && (
          <span className="mt-1 text-[10px] font-normal uppercase tracking-[0.42em] opacity-70">
            Limited
          </span>
        )}
      </span>
    </span>
  )
}
