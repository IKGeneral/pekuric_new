import { cn } from '@/lib/utils'
import type { ReactNode } from 'react'

/**
 * Signature section label: a 4px solid Carbon square followed by tiny
 * uppercase text. Replaces the conventional bullet/icon per the spec.
 */
type SectionLabelProps = {
  children: ReactNode
  className?: string
  onDark?: boolean
}

export default function SectionLabel({ children, className, onDark = false }: SectionLabelProps) {
  return (
    <span
      className={cn(
        'inline-flex items-center gap-2 text-label font-normal uppercase tracking-[0.12em]',
        onDark ? 'text-paper-white' : 'text-carbon-warm',
        className,
      )}
    >
      <span
        aria-hidden="true"
        className={cn(
          'h-1 w-1 shrink-0',
          onDark ? 'bg-paper-white' : 'bg-carbon-warm',
        )}
      />
      {children}
    </span>
  )
}
