import { imagePair } from '@/data/content'

/**
 * Two full-bleed photos side by side, each with the signature 80px radius.
 * No captions, no borders, no shadows — the images float on the vellum canvas.
 */
export default function ImagePair() {
  return (
    <section className="container-t1 py-12">
      <div className="grid gap-6 md:grid-cols-2">
        {imagePair.images.map((image) => (
          <div
            key={image.src}
            className="aspect-[4/3] overflow-hidden rounded-card"
          >
            <img
              src={image.src}
              alt={image.alt}
              className="h-full w-full object-cover"
              loading="lazy"
            />
          </div>
        ))}
      </div>
    </section>
  )
}
