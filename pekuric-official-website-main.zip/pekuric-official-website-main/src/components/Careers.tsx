import { Link } from '@tanstack/react-router'
import { Button } from '@/components/ui/button'
import SectionLabel from '@/components/SectionLabel'
import { careers } from '@/data/content'

export default function Careers() {
  return (
    <section id="careers" className="container-t1 py-24">
      <div className="grid items-center gap-12 md:grid-cols-2 md:gap-16">
        {/* Text */}
        <div className="flex flex-col items-start gap-6">
          <SectionLabel>{careers.label}</SectionLabel>
          <h2 className="text-[clamp(30px,5vw,52px)] font-light leading-none tracking-[0.52px] text-carbon-warm">
            {careers.headline}
          </h2>
          <p className="max-w-md text-body font-normal text-carbon-warm/80">
            {careers.body}
          </p>
          <Button asChild variant="filled" className="mt-2">
            <Link to={careers.cta.to}>{careers.cta.label}</Link>
          </Button>
        </div>

        {/* Image */}
        <div className="aspect-[5/4] overflow-hidden rounded-card">
          <img
            src={careers.image}
            alt={careers.imageAlt}
            className="h-full w-full object-cover"
            loading="lazy"
          />
        </div>
      </div>
    </section>
  )
}
