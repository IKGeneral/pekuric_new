import SectionLabel from '@/components/SectionLabel'
import { testimonial } from '@/data/content'

/**
 * Carbon Warm quote panel — a rhythm break from the vellum canvas. Large
 * whisper-light quote, tiny attribution. No portrait, no shadow.
 */
export default function Testimonial() {
  return (
    <section className="container-t1 py-12">
      <figure className="rounded-[48px] bg-carbon-warm px-8 py-16 md:px-16 md:py-24">
        <SectionLabel onDark>{testimonial.label}</SectionLabel>
        <blockquote className="mt-8 max-w-4xl text-[clamp(24px,3.5vw,40px)] font-light leading-tight tracking-[0.3px] text-paper-white">
          “{testimonial.quote}”
        </blockquote>
        <figcaption className="mt-10 text-body-sm font-normal text-paper-white/70">
          <span className="text-paper-white">{testimonial.name}</span>
          <span className="mx-2 text-paper-white/40">·</span>
          {testimonial.role}
        </figcaption>
      </figure>
    </section>
  )
}
