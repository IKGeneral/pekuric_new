import { createFileRoute, notFound } from '@tanstack/react-router'
import ProjectDetail from '@/pages/ProjectDetail'
import NotFound from '@/pages/NotFound'
import { getProjectBySlug } from '@/data/projects'
import {
  notFoundHead,
  projectJsonLd,
  projectTitle,
  seoHead,
  truncateDescription,
} from '@/lib/seo'

export const Route = createFileRoute('/_layout/our-projects/$slug')({
  loader: ({ params }) => {
    const project = getProjectBySlug(params.slug)

    if (!project) {
      throw notFound({ routeId: '/_layout/our-projects/$slug' })
    }

    return project
  },
  head: ({ params, loaderData }) => {
    const project = loaderData ?? getProjectBySlug(params.slug)

    if (!project) {
      return notFoundHead()
    }

    return seoHead({
      title: projectTitle(project.title, project.location),
      description: truncateDescription(
        `${project.summary} Delivered by Pekuric Limited in ${project.location}.`,
      ),
      path: `/our-projects/${project.slug}`,
      image: project.image,
      type: 'website',
      breadcrumbs: [
        ['Our Projects', '/our-projects'],
        [project.title, `/our-projects/${project.slug}`],
      ],
      jsonLd: [projectJsonLd(project)],
    })
  },
  notFoundComponent: () => <NotFound />,
  component: ProjectDetail,
})
