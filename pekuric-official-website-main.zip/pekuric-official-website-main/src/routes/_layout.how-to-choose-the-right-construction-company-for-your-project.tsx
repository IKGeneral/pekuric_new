import { createFileRoute } from '@tanstack/react-router'
import ArticleDetail from '@/pages/ArticleDetail'
import { getArticleBySlug } from '@/data/articles'
import { articleJsonLd, canonicalUrl, seoHead } from '@/lib/seo'

const SLUG = 'how-to-choose-the-right-construction-company-for-your-project'

export const Route = createFileRoute(
  '/_layout/how-to-choose-the-right-construction-company-for-your-project',
)({
  head: () => {
    const article = getArticleBySlug(SLUG)!

    return seoHead({
      title: 'How to Choose the Right Construction Company | Pekuric',
      description:
        'What to look for in a construction partner: experience, licensing, transparent pricing, and communication. From Pekuric Limited.',
      path: `/${SLUG}`,
      image: '/images/hero-poster.jpg',
      type: 'article',
      trailingSlash: true,
      breadcrumbs: [
        ['News & Insights', '/news-insights'],
        [article.title, `/${SLUG}`],
      ],
      jsonLd: [
        articleJsonLd({
          ...article,
          url: canonicalUrl(`/${SLUG}`, true),
        }),
      ],
    })
  },
  component: () => <ArticleDetail slug={SLUG} />,
})
