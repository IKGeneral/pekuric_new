import { createFileRoute } from '@tanstack/react-router'
import Projects from '@/pages/Projects'
import { projectsPage } from '@/data/content'
import { seoHead } from '@/lib/seo'

export const Route = createFileRoute('/_layout/our-projects/')({
  head: () =>
    seoHead({
      title: 'Construction Projects in Edo State | Pekuric',
      description:
        'Landmark projects delivered across Edo State and Nigeria: transit terminals, public buildings, roads, industrial and commercial developments.',
      breadcrumbs: [['Our Projects', '/our-projects']],
      path: '/our-projects',
      image: projectsPage.cards[0].image,
      type: 'website',
    }),
  component: Projects,
})
