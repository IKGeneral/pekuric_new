import { createFileRoute } from '@tanstack/react-router'
import ArticleDetail from '@/pages/ArticleDetail'
import { getArticleBySlug } from '@/data/articles'
import { articleJsonLd, canonicalUrl, seoHead } from '@/lib/seo'

const SLUG = 'the-future-of-building-why-sustainable-construction-matters'

export const Route = createFileRoute(
  '/_layout/the-future-of-building-why-sustainable-construction-matters',
)({
  head: () => {
    const article = getArticleBySlug(SLUG)!

    return seoHead({
      title: 'Why Sustainable Construction Matters | Pekuric',
      description:
        'Sustainable construction is no longer optional. Pekuric Limited on eco-friendly materials, energy efficiency, and building green.',
      path: `/${SLUG}`,
      image: '/images/hero-poster.jpg',
      type: 'article',
      trailingSlash: true,
      breadcrumbs: [
        ['News & Insights', '/news-insights'],
        [article.title, `/${SLUG}`],
      ],
      jsonLd: [
        articleJsonLd({
          ...article,
          url: canonicalUrl(`/${SLUG}`, true),
        }),
      ],
    })
  },
  component: () => <ArticleDetail slug={SLUG} />,
})
