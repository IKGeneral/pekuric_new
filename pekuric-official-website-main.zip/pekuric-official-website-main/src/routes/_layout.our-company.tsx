import { createFileRoute } from '@tanstack/react-router'
import Company from '@/pages/Company'
import { companyPage } from '@/data/content'
import { seoHead } from '@/lib/seo'

export const Route = createFileRoute('/_layout/our-company')({
  head: () =>
    seoHead({
      title: 'Civil Engineering Company in Benin City | Pekuric',
      description:
        'Pekuric Limited is a Benin City civil engineering company founded in 2017, delivering buildings, roads and infrastructure with owned plant and equipment.',
      breadcrumbs: [['Our Company', '/our-company']],
      path: '/our-company',
      image: companyPage.image,
      type: 'website',
    }),
  component: Company,
})
