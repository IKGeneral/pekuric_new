import { createFileRoute } from '@tanstack/react-router'
import Services from '@/pages/Services'
import { hero, servicesPage } from '@/data/content'
import { seoHead, serviceJsonLd } from '@/lib/seo'

export const Route = createFileRoute('/_layout/our-services')({
  head: () =>
    seoHead({
      title: 'Building & Road Construction Services | Pekuric',
      description:
        'Building construction, road construction, renovation, architecture, consulting and project management for government, corporate and private clients.',
      breadcrumbs: [['Our Services', '/our-services']],
      jsonLd: serviceJsonLd(servicesPage.items),
      path: '/our-services',
      image: hero.poster,
      type: 'website',
    }),
  component: Services,
})
