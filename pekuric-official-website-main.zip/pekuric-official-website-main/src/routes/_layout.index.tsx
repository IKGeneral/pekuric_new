import { createFileRoute } from '@tanstack/react-router'
import Home from '@/pages/Home'
import { hero } from '@/data/content'
import { seoHead } from '@/lib/seo'

export const Route = createFileRoute('/_layout/')({
  head: () =>
    seoHead({
      title: 'Construction Company in Benin City | Pekuric Limited',
      description:
        'Construction and civil engineering company in Benin City, Edo State. Building, roads, renovation and project management across Nigeria since 2017.',
      path: '/',
      image: hero.poster,
      type: 'website',
    }),
  component: Home,
})
