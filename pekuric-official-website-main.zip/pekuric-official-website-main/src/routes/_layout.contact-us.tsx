import { createFileRoute } from '@tanstack/react-router'
import Contact from '@/pages/Contact'
import { hero } from '@/data/content'
import { seoHead } from '@/lib/seo'

export const Route = createFileRoute('/_layout/contact-us')({
  head: () =>
    seoHead({
      title: 'Contact Pekuric | Builders in Benin City',
      description:
        'Call or email Pekuric Limited in Benin City, Edo State to discuss your construction, road or renovation project.',
      breadcrumbs: [['Contact Us', '/contact-us']],
      path: '/contact-us',
      image: hero.poster,
      type: 'website',
    }),
  component: Contact,
})
