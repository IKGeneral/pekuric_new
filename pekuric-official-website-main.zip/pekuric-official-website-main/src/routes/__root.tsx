import { createRootRoute, HeadContent, Outlet, Scripts } from '@tanstack/react-router'
import appCss from '@/index.css?url'
import { siteJsonLd } from '@/lib/seo'

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { title: 'Pekuric Limited \u2014 Construction & Engineering' },
      { charSet: 'UTF-8' },
      { name: 'viewport', content: 'width=device-width, initial-scale=1.0' },
      {
        name: 'description',
        content:
          'Pekuric Limited \u2014 precision construction, engineering, and project management in Benin City, Nigeria. Your project. Our expertise. Zero guesswork.',
      },
      { 'script:ld+json': siteJsonLd },
    ],
    links: [
      { rel: 'icon', type: 'image/svg+xml', href: '/favicon.svg' },
      { rel: 'mask-icon', href: '/favicon.svg', color: '#6a0002' },
      { rel: 'stylesheet', href: appCss },
    ],
  }),
  component: RootComponent,
})

function RootComponent() {
  return (
    <html lang="en-NG">
      <head>
        <HeadContent />
      </head>
      <body className="bg-vellum">
        <Outlet />
        <Scripts />
      </body>
    </html>
  )
}
