import { createFileRoute } from '@tanstack/react-router'
import TermsAndConditions from '@/pages/TermsAndConditions'
import { hero } from '@/data/content'
import { seoHead } from '@/lib/seo'

export const Route = createFileRoute('/_layout/terms-and-conditions')({
  head: () =>
    seoHead({
      title: 'Terms & Conditions | Pekuric Limited',
      description:
        'The terms governing use of PEKURIC Limited\u2019s website, including intellectual property, liability, and governing law.',
      path: '/terms-and-conditions',
      breadcrumbs: [['Terms & Conditions', '/terms-and-conditions']],
      image: hero.poster,
      type: 'website',
    }),
  component: TermsAndConditions,
})
