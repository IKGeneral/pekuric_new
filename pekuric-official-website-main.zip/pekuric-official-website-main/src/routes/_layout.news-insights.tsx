import { createFileRoute } from '@tanstack/react-router'
import NewsInsights from '@/pages/NewsInsights'
import { seoHead } from '@/lib/seo'

export const Route = createFileRoute('/_layout/news-insights')({
  head: () =>
    seoHead({
      title: 'Construction News & Insights | Pekuric',
      description:
        'Practical advice and updates from Pekuric Limited on sustainable construction, choosing a builder, and home renovation.',
      path: '/news-insights',
      breadcrumbs: [['News & Insights', '/news-insights']],
      image: '/images/hero-poster.jpg',
      type: 'website',
      trailingSlash: true,
    }),
  component: NewsInsights,
})
