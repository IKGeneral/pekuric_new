import { createFileRoute } from '@tanstack/react-router'
import ArticleDetail from '@/pages/ArticleDetail'
import { getArticleBySlug } from '@/data/articles'
import { articleJsonLd, canonicalUrl, seoHead } from '@/lib/seo'

const SLUG = '7-signs-its-time-to-renovate-your-home'

export const Route = createFileRoute('/_layout/7-signs-its-time-to-renovate-your-home')({
  head: () => {
    const article = getArticleBySlug(SLUG)!

    return seoHead({
      title: "7 Signs It's Time to Renovate Your Home | Pekuric",
      description:
        'From outdated design to rising utility costs, seven signs your home may be ready for renovation. From Pekuric Limited.',
      path: `/${SLUG}`,
      image: '/images/hero-poster.jpg',
      type: 'article',
      trailingSlash: true,
      breadcrumbs: [
        ['News & Insights', '/news-insights'],
        [article.title, `/${SLUG}`],
      ],
      jsonLd: [
        articleJsonLd({
          ...article,
          url: canonicalUrl(`/${SLUG}`, true),
        }),
      ],
    })
  },
  component: () => <ArticleDetail slug={SLUG} />,
})
