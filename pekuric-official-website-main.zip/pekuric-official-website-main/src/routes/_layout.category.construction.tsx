import { createFileRoute } from '@tanstack/react-router'
import CategoryConstruction from '@/pages/CategoryConstruction'
import { seoHead } from '@/lib/seo'

export const Route = createFileRoute('/_layout/category/construction')({
  head: () =>
    seoHead({
      title: 'Construction Articles & Advice | Pekuric',
      description: 'Articles from Pekuric Limited filed under the Construction category.',
      path: '/category/construction',
      breadcrumbs: [
        ['News & Insights', '/news-insights'],
        ['Construction', '/category/construction'],
      ],
      image: '/images/hero-poster.jpg',
      type: 'website',
      trailingSlash: true,
    }),
  component: CategoryConstruction,
})
