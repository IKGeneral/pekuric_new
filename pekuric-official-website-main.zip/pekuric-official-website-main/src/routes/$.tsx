import { createFileRoute, notFound } from '@tanstack/react-router'
import NotFound from '@/pages/NotFound'
import { notFoundHead } from '@/lib/seo'

export const Route = createFileRoute('/$')({
  head: notFoundHead,
  beforeLoad: () => {
    throw notFound({ routeId: '/$' })
  },
  notFoundComponent: () => <NotFound withShell />,
})
