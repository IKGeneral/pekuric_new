import { createFileRoute } from '@tanstack/react-router'
import PrivacyPolicy from '@/pages/PrivacyPolicy'
import { hero } from '@/data/content'
import { seoHead } from '@/lib/seo'

export const Route = createFileRoute('/_layout/privacy-policy')({
  head: () =>
    seoHead({
      title: 'Privacy Policy | Pekuric Limited',
      description:
        'How PEKURIC Limited collects, uses, and protects personal information submitted through this website, in line with the Nigeria Data Protection Act 2023.',
      path: '/privacy-policy',
      breadcrumbs: [['Privacy Policy', '/privacy-policy']],
      image: hero.poster,
      type: 'website',
    }),
  component: PrivacyPolicy,
})
